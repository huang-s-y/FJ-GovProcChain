import sys
import unittest
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from govprocchain.anomaly import RISK_LABELS, detect_anomalies
from govprocchain.hash_utils import hash_record, verify_record
from govprocchain.mock_chain import MockEvidenceChain


class CoreTest(unittest.TestCase):
    def test_hash_changes_after_tampering(self) -> None:
        record = {
            "record_id": "T-001",
            "project_name": "sample project",
            "contract_amount": "1000",
        }
        digest = hash_record(record)
        self.assertTrue(verify_record(record, digest))
        tampered = dict(record)
        tampered["contract_amount"] = "9999"
        self.assertFalse(verify_record(tampered, digest))

    def test_chain_detects_broken_previous_hash(self) -> None:
        chain = MockEvidenceChain()
        chain.append_record("A", "1" * 64)
        chain.append_record("B", "2" * 64)
        self.assertTrue(chain.verify_chain())
        chain.blocks[2].previous_hash = "broken"
        self.assertFalse(chain.verify_chain())

    def test_anomaly_flags_extreme_amount(self) -> None:
        df = pd.DataFrame(
            [
                {
                    "record_id": "A",
                    "project_name": "network appliance purchase",
                    "supplier": "supplier-a",
                    "budget_amount": 100,
                    "contract_amount": 100,
                    "notice_date": "2024-01-01",
                    "sign_date": "2024-01-01",
                    "project_no": "A",
                    "buyer": "buyer-a",
                    "procurement_method": "open tender",
                },
                {
                    "record_id": "B",
                    "project_name": "library database renewal",
                    "supplier": "supplier-b",
                    "budget_amount": 120,
                    "contract_amount": 120,
                    "notice_date": "2024-01-01",
                    "sign_date": "2024-01-01",
                    "project_no": "B",
                    "buyer": "buyer-b",
                    "procurement_method": "open tender",
                },
                {
                    "record_id": "C",
                    "project_name": "district data center upgrade",
                    "supplier": "supplier-c",
                    "budget_amount": 10000,
                    "contract_amount": 10000,
                    "notice_date": "2024-01-01",
                    "sign_date": "2024-01-01",
                    "project_no": "C",
                    "buyer": "buyer-c",
                    "procurement_method": "open tender",
                },
            ]
        )
        result = detect_anomalies(df)
        risk = result.loc[result["record_id"] == "C", "rule_risk_score"].iloc[0]
        self.assertGreaterEqual(risk, 30)
        self.assertIn("iforest_score", result.columns)
        self.assertIn("red_flag_score", result.columns)

    def test_risk_level_thresholds(self) -> None:
        titles = [
            "network appliance purchase",
            "library database renewal",
            "campus lighting repair",
            "water meter calibration",
            "archive cabinet supply",
            "road sensor maintenance",
            "clinic printer leasing",
            "fire alarm inspection",
            "training room projector",
            "office chair replacement",
            "server room cleaning",
            "public notice printing",
        ]
        df = pd.DataFrame(
            [
                {
                    "record_id": f"A{i}",
                    "project_name": title,
                    "supplier": f"supplier-{i}",
                    "budget_amount": 1000,
                    "contract_amount": 1000,
                    "notice_date": "2024-01-01",
                    "sign_date": "2024-01-01",
                    "project_no": f"A{i}",
                    "buyer": f"buyer-{i}",
                    "procurement_method": "open tender",
                }
                for i, title in enumerate(titles)
            ]
        )
        result = detect_anomalies(df)
        self.assertTrue((result["rule_risk_score"] < 10).any())
        self.assertTrue(set(result["risk_level"]).issubset(set(RISK_LABELS)))


if __name__ == "__main__":
    unittest.main()

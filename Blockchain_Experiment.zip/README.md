# FJ-GovProcChain：区块链公共资源交易数据可信治理原型

本项目对应课程论文《区块链赋能城市公共资源交易数据可信治理研究——融合智能合约存证与异常识别的原型实现》。原型按原版完整方案的 GovProc-Chain 设计实现，并将数据口径调整为福建政府采购/公共资源交易公开信息，验证“链下数据处理、链上哈希存证、异常识别预警、智能合约状态流转、监管追溯核验”的闭环流程。

## 1. 目录说明

```text
Blockchain_Experiment/
├─ app/streamlit_app.py                 # 可选监管看板
├─ contracts/RecordRegistry.sol         # Solidity 智能合约
├─ data/fujian_procurement_sample.csv   # 课程实验样本
├─ data/fujian_procurement_seed.csv     # 首次扩展时保留的原始种子样本
├─ docs/                                # 论文和图表输出
├─ outputs/                             # 运行结果输出
├─ scripts/expand_dataset.py            # 千级样本扩展脚本
├─ scripts/run_pipeline.py              # 一键运行实验
├─ scripts/scrape_fujian_pages.py       # 可选网页解析脚本
├─ src/govprocchain/                    # Python 核心模块
└─ tests/test_core.py                   # 基础单元测试
```

## 2. Python 基础版运行方式

建议使用 Python 3.10 或以上版本。

```powershell
cd "E:\学习资料\！区块链技术\课程设计\Blockchain_Experiment"
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python scripts\expand_dataset.py --target 1260 --simulations 30
python scripts\run_pipeline.py
python -m unittest discover -s tests
```

运行后会在 `outputs/` 下生成：

- `registry.csv`：哈希登记表
- `blocks.json`：Python 模拟链区块数据
- `anomaly_results.csv`：异常识别结果
- `tamper_report.json`：篡改校验实验结果
- `status_events.csv`：监管状态流转事件
- `storage_efficiency.csv`：链上全文存储与哈希摘要存储的大小对比
- `sensitivity_results.csv`：风险权重和阈值敏感性分析
- `injected_anomaly_eval.json`：人工注入异常的功能测试结果
- `summary.json`：实验汇总指标

## 3. 可选监管看板

```powershell
streamlit run app\streamlit_app.py
```

如果提示没有 `streamlit`，执行：

```powershell
python -m pip install streamlit
```

## 4. Solidity 合约运行方式

### 方式 A：Remix 在线运行，最适合课程演示

1. 打开 [Remix IDE](https://remix.ethereum.org/)。
2. 新建 `RecordRegistry.sol`，复制 `contracts/RecordRegistry.sol` 的内容。
3. 在左侧 Solidity Compiler 中选择 `0.8.24` 或兼容版本，点击 Compile。
4. 在 Deploy & Run Transactions 中选择 `Remix VM` 环境，点击 Deploy。
5. 依次调用：
   - `registerRecord(recordId, recordType, dataHash, sourceUri)` 登记数据哈希；
   - `verifyRecord(recordId, dataHash)` 校验是否被篡改；
   - `updateRecord(recordId, newHash, reason)` 登记合规变更版本；
   - `flagRisk(recordId, riskType, riskScore)` 或 `markRisk(recordId, riskScore, riskReason)` 标记风险；
   - `reviewRisk(recordId, status, comment)` 或 `startReview/closeRisk` 模拟监管闭环；
   - `getRecordTrace(recordId)` 查询登记、更新、预警、核查和关闭轨迹。

### 方式 B：本地运行

需要下载：

- Node.js LTS
- Ganache 或 Hardhat
- MetaMask（如果要接浏览器钱包）

课程展示更推荐 Remix；它不需要本地安装 Solidity 编译器，也不容易卡在依赖下载上。

## 5. 数据边界说明

`data/fujian_procurement_sample.csv` 包含两类记录：

- `official_web_excerpt` / `official_public_structured_sample`：根据福建政府采购/公共资源交易公开网页字段整理和扩展的官方公开字段样本；
- `course_simulation`：为验证篡改检测、主体集中度、文本相似和金额偏离等实验而构造的模拟风险样本。

论文中应明确：异常识别结果只表示“风险线索”或“数据异常模式”，不能直接等同于违法违规结论；本课程原型不追求全量爬取福建省所有采购数据，而是通过 1000 条以上样本验证“结构化解析—哈希存证—异常识别—监管追溯”的闭环可行性。

from __future__ import annotations

import json
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Iterable, List, Sequence, Tuple

import pandas as pd
from docx import Document
from docx.enum.section import WD_ORIENT
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Inches, Pt, RGBColor
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
TEMPLATE = ROOT.parent / "（课程论文模板）学号-姓名-论文名.docx"
OUTPUT_DIR = ROOT / "outputs"
DOCS_DIR = ROOT / "docs"
FIG_DIR = DOCS_DIR / "figures"
PAPER_PATH = DOCS_DIR / "区块链赋能城市公共资源交易数据可信治理研究_课程论文.docx"

BLUE = RGBColor(31, 78, 121)
GRAY = RGBColor(90, 90, 90)
LIGHT_BLUE = "D9EAF7"
LIGHT_GRAY = "F2F4F7"


def font_path() -> str:
    candidates = [
        r"C:\Windows\Fonts\msyh.ttc",
        r"C:\Windows\Fonts\simhei.ttf",
        r"C:\Windows\Fonts\simsun.ttc",
    ]
    for item in candidates:
        if Path(item).exists():
            return item
    return ""


FONT_PATH = font_path()


def get_font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    if FONT_PATH:
        try:
            return ImageFont.truetype(FONT_PATH, size=size)
        except OSError:
            pass
    return ImageFont.load_default()


def wrap_text(text: str, max_chars: int) -> str:
    """按中文字符长度进行简单换行，保证流程图中文字不溢出。"""
    lines = []
    current = ""
    for ch in text:
        current += ch
        if len(current) >= max_chars:
            lines.append(current)
            current = ""
    if current:
        lines.append(current)
    return "\n".join(lines)


def draw_centered(draw: ImageDraw.ImageDraw, box: Tuple[int, int, int, int], text: str, font: ImageFont.FreeTypeFont, fill: str) -> None:
    lines = text.split("\n")
    line_heights = [draw.textbbox((0, 0), line, font=font)[3] for line in lines]
    total_h = sum(line_heights) + (len(lines) - 1) * 8
    y = box[1] + (box[3] - box[1] - total_h) / 2
    for line in lines:
        bbox = draw.textbbox((0, 0), line, font=font)
        x = box[0] + (box[2] - box[0] - (bbox[2] - bbox[0])) / 2
        draw.text((x, y), line, font=font, fill=fill)
        y += (bbox[3] - bbox[1]) + 8


def draw_arrow(draw: ImageDraw.ImageDraw, start: Tuple[int, int], end: Tuple[int, int], color: str = "#315F88") -> None:
    draw.line([start, end], fill=color, width=5)
    x1, y1 = start
    x2, y2 = end
    if x2 >= x1:
        points = [(x2, y2), (x2 - 18, y2 - 10), (x2 - 18, y2 + 10)]
    else:
        points = [(x2, y2), (x2 + 18, y2 - 10), (x2 + 18, y2 + 10)]
    draw.polygon(points, fill=color)


def draw_box(draw: ImageDraw.ImageDraw, box: Tuple[int, int, int, int], text: str, fill: str, outline: str = "#315F88") -> None:
    draw.rounded_rectangle(box, radius=22, fill=fill, outline=outline, width=3)
    draw_centered(draw, box, text, get_font(28), "#18344D")


def save_architecture_diagram(path: Path) -> None:
    image = Image.new("RGB", (1600, 900), "white")
    draw = ImageDraw.Draw(image)
    title_font = get_font(44)
    draw.text((70, 42), "FJ-GovProcChain 系统架构", font=title_font, fill="#0B2545")

    boxes = [
        ((70, 170, 340, 310), "福建政府采购网\n公共资源交易平台\n公共数据开放平台", "#EAF4EF"),
        ((430, 170, 700, 310), "链下数据处理\n字段解析/清洗\n规范化 JSON", "#E8EEF7"),
        ((790, 170, 1060, 310), "哈希存证\nSHA-256\n链下原文+链上摘要", "#FFF2CC"),
        ((1150, 170, 1420, 310), "智能合约\n登记/校验/预警\n核查/关闭", "#FCE4D6"),
        ((430, 500, 700, 690), "异常识别\n金额偏离\n主体集中\n文本相似\n时间异常", "#E2F0D9"),
        ((790, 500, 1060, 690), "监管追溯\n事件日志\n状态流转\n责任留痕", "#EADCF8"),
        ((1150, 500, 1420, 690), "可视化看板\n风险列表\n哈希校验\n证据查询", "#DDEBF7"),
    ]
    for box, text, fill in boxes:
        draw_box(draw, box, text, fill)

    arrows = [
        ((340, 240), (430, 240)),
        ((700, 240), (790, 240)),
        ((1060, 240), (1150, 240)),
        ((565, 310), (565, 490)),
        ((700, 595), (790, 595)),
        ((1060, 595), (1150, 595)),
        ((1285, 500), (1285, 310)),
    ]
    for start, end in arrows:
        draw_arrow(draw, start, end)

    draw.text((70, 790), "设计原则：链下保存原文与特征，链上保存哈希与状态；异常识别只提供风险线索，不替代人工监管裁量。", font=get_font(28), fill="#555555")
    image.save(path)


def save_workflow_diagram(path: Path) -> None:
    image = Image.new("RGB", (1600, 700), "white")
    draw = ImageDraw.Draw(image)
    draw.text((70, 42), "实验落地流程", font=get_font(44), fill="#0B2545")
    steps = [
        "公开网页\n样本整理",
        "字段解析\n与清洗",
        "规范化\n哈希计算",
        "链上登记\n事件留痕",
        "篡改校验\n一致性比对",
        "异常识别\n风险评分",
        "监管闭环\n状态流转",
    ]
    x = 50
    y = 210
    w = 170
    h = 130
    for idx, step in enumerate(steps):
        draw_box(draw, (x, y, x + w, y + h), step, "#EAF2F8")
        if idx < len(steps) - 1:
            draw_arrow(draw, (x + w, y + h // 2), (x + w + 30, y + h // 2))
        x += w + 50
    draw.text((70, 520), "输出：registry、blocks、anomaly、tamper、storage、sensitivity、status、summary 等实验结果文件", font=get_font(25), fill="#555555")
    image.save(path)


def save_state_diagram(path: Path) -> None:
    image = Image.new("RGB", (1500, 760), "white")
    draw = ImageDraw.Draw(image)
    draw.text((70, 42), "智能合约风险状态机", font=get_font(44), fill="#0B2545")
    boxes = [
        ((110, 260, 370, 410), "已登记\nRegistered", "#E2F0D9"),
        ((470, 260, 730, 410), "已预警\nWarned", "#FFF2CC"),
        ((830, 260, 1090, 410), "核查中\nReviewing", "#FCE4D6"),
        ((1190, 260, 1450, 410), "已关闭\nClosed", "#EADCF8"),
    ]
    for box, text, fill in boxes:
        draw_box(draw, box, text, fill)
    draw_arrow(draw, (370, 335), (470, 335))
    draw_arrow(draw, (730, 335), (830, 335))
    draw_arrow(draw, (1090, 335), (1190, 335))
    draw.text((395, 285), "风险标记", font=get_font(24), fill="#555555")
    draw.text((748, 285), "启动核查", font=get_font(24), fill="#555555")
    draw.text((1116, 285), "关闭处理", font=get_font(24), fill="#555555")
    draw.text((110, 560), "合约记录每次状态变更事件，形成“风险发现—人工核查—处理结论”的可追溯链路。", font=get_font(28), fill="#555555")
    image.save(path)


def save_result_chart(path: Path, anomaly: pd.DataFrame) -> None:
    image = Image.new("RGB", (1400, 820), "white")
    draw = ImageDraw.Draw(image)
    draw.text((70, 42), "异常识别结果分布", font=get_font(44), fill="#0B2545")
    counts = anomaly["risk_level"].value_counts().reindex(["正常", "低风险", "中风险", "高风险"]).fillna(0).astype(int)
    max_count = max(int(counts.max()), 1)
    colors = ["#A9D18E", "#9DC3E6", "#FFD966", "#F4B183"]
    x0, y0 = 160, 620
    bar_w = 180
    gap = 100
    for idx, (label, count) in enumerate(counts.items()):
        x = x0 + idx * (bar_w + gap)
        h = int(380 * count / max_count)
        draw.rectangle((x, y0 - h, x + bar_w, y0), fill=colors[idx], outline="#315F88", width=2)
        draw.text((x + 65, y0 - h - 42), str(count), font=get_font(30), fill="#0B2545")
        draw.text((x + 35, y0 + 24), label, font=get_font(28), fill="#333333")
    draw.line((110, y0, 1230, y0), fill="#555555", width=3)
    draw.text((70, 720), "分级阈值：<10 正常，10—30 低风险，30—60 中风险，≥60 高风险；结果仅表示复核优先级。", font=get_font(24), fill="#555555")
    image.save(path)


def draw_table_image(
    draw: ImageDraw.ImageDraw,
    x: int,
    y: int,
    widths: Sequence[int],
    row_h: int,
    headers: Sequence[str],
    rows: Sequence[Sequence[str]],
    header_fill: str = "#D9EAF7",
) -> None:
    font_header = get_font(21)
    font_body = get_font(19)
    cur_x = x
    for idx, header in enumerate(headers):
        draw.rectangle((cur_x, y, cur_x + widths[idx], y + row_h), fill=header_fill, outline="#8FA6BC", width=2)
        draw.text((cur_x + 10, y + 13), str(header), font=font_header, fill="#18344D")
        cur_x += widths[idx]
    for ridx, row in enumerate(rows):
        cur_y = y + row_h * (ridx + 1)
        cur_x = x
        fill = "#FFFFFF" if ridx % 2 == 0 else "#F7FAFC"
        for cidx, value in enumerate(row):
            draw.rectangle((cur_x, cur_y, cur_x + widths[cidx], cur_y + row_h), fill=fill, outline="#D5DEE7", width=1)
            draw.text((cur_x + 10, cur_y + 13), wrap_text(str(value), max(8, widths[cidx] // 22)), font=font_body, fill="#333333")
            cur_x += widths[cidx]


def ellipsize(value: object, max_chars: int) -> str:
    text = "" if pd.isna(value) else str(value)
    return text if len(text) <= max_chars else text[: max_chars - 3] + "..."


def save_contract_log_figure(path: Path, contract_log: pd.DataFrame) -> None:
    image = Image.new("RGB", (1600, 980), "#F5F7FA")
    draw = ImageDraw.Draw(image)
    draw.text((70, 42), "Solidity 合约部署与调用日志", font=get_font(44), fill="#0B2545")
    deploy = contract_log.iloc[0]
    draw.rounded_rectangle((70, 125, 1530, 260), radius=18, fill="#FFFFFF", outline="#CAD6E0", width=2)
    draw.text((100, 152), f"环境：{deploy['environment']}", font=get_font(26), fill="#18344D")
    draw.text((100, 198), f"合约地址：{ellipsize(deploy['contract_address'], 30)}", font=get_font(24), fill="#18344D")
    draw.text((780, 152), f"部署交易：{ellipsize(deploy['tx_hash'], 32)}", font=get_font(24), fill="#18344D")
    draw.text((780, 198), f"部署 gas：{int(deploy['gas_used']):,}", font=get_font(24), fill="#18344D")
    rows = [
        (
            str(row["step"]),
            row["action"],
            "-" if pd.isna(row["record_id"]) or str(row["record_id"]).strip() == "" else str(row["record_id"]),
            row["status_after_call"],
            str(row["result"])[:18],
            ellipsize(row["tx_hash"], 17),
        )
        for _, row in contract_log.head(7).iterrows()
    ]
    draw_table_image(
        draw,
        70,
        310,
        [80, 220, 180, 230, 180, 430],
        62,
        ["步骤", "合约动作", "记录", "状态", "结果", "交易哈希"],
        rows,
        header_fill="#EAF4EF",
    )
    draw.text((70, 890), "说明：日志用于课程原型演示，记录合约部署、登记、校验、预警、核查、关闭和轨迹查询的调用结果。", font=get_font(24), fill="#555555")
    image.save(path)


def save_dashboard_snapshot(path: Path, summary: dict, anomaly: pd.DataFrame, model_comparison: pd.DataFrame) -> None:
    image = Image.new("RGB", (1600, 1100), "#F4F6F8")
    draw = ImageDraw.Draw(image)
    draw.text((70, 40), "FJ-GovProcChain 监管看板截图", font=get_font(42), fill="#0B2545")
    metrics = [
        ("样本总数", summary["total_records"]),
        ("官方样本", summary["official_excerpt_records"]),
        ("模拟样本", summary["simulation_records"]),
        ("复核候选", summary["risk_records"]),
        ("状态事件", summary["status_events"]),
        ("节省比例", f"{summary['storage_saving_ratio_at_sample']:.2%}"),
    ]
    for idx, (label, value) in enumerate(metrics):
        x = 70 + idx * 245
        draw.rounded_rectangle((x, 125, x + 220, 235), radius=12, fill="#FFFFFF", outline="#D1DCE8", width=2)
        draw.text((x + 18, 148), label, font=get_font(21), fill="#5F6B7A")
        draw.text((x + 18, 180), str(value), font=get_font(31), fill="#18344D")

    counts = anomaly["risk_level"].value_counts().reindex(["正常", "低风险", "中风险", "高风险"]).fillna(0).astype(int)
    draw.rounded_rectangle((70, 280, 760, 715), radius=14, fill="#FFFFFF", outline="#D1DCE8", width=2)
    draw.text((105, 310), "异常识别结果分布", font=get_font(28), fill="#18344D")
    max_count = max(int(counts.max()), 1)
    colors = ["#A9D18E", "#9DC3E6", "#FFD966", "#F4B183"]
    for idx, (label, count) in enumerate(counts.items()):
        x = 130 + idx * 145
        h = int(260 * count / max_count)
        draw.rectangle((x, 640 - h, x + 82, 640), fill=colors[idx], outline="#315F88", width=2)
        draw.text((x + 10, 650), label, font=get_font(21), fill="#333333")
        draw.text((x + 12, 606 - h), str(count), font=get_font(22), fill="#18344D")

    draw.rounded_rectangle((820, 280, 1530, 715), radius=14, fill="#FFFFFF", outline="#D1DCE8", width=2)
    draw.text((855, 310), "模型对比 Top-K 结果", font=get_font(28), fill="#18344D")
    rows = [
        (row["model_name"], str(row["true_positive"]), f"{float(row['f1_at_k']):.4f}")
        for _, row in model_comparison.head(4).iterrows()
    ]
    draw_table_image(draw, 855, 370, [360, 130, 130], 62, ["模型", "命中", "F1"], rows, header_fill="#FFF2CC")

    top = anomaly.sort_values("rule_risk_score", ascending=False).head(4)
    rows2 = [
        (row["record_id"], f"{float(row['rule_risk_score']):.2f}", row["risk_level"], ellipsize(row["risk_reason"], 24))
        for _, row in top.iterrows()
    ]
    draw.rounded_rectangle((70, 755, 1530, 1055), radius=14, fill="#FFFFFF", outline="#D1DCE8", width=2)
    draw.text((105, 785), "Top 风险线索", font=get_font(26), fill="#18344D")
    draw_table_image(draw, 105, 825, [210, 150, 150, 820], 42, ["记录", "分数", "等级", "原因"], rows2, header_fill="#E8EEF7")
    image.save(path)


def create_figures() -> None:
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    if not (OUTPUT_DIR / "summary.json").exists():
        subprocess.run([sys.executable, str(ROOT / "scripts" / "run_pipeline.py")], check=True)
    anomaly = pd.read_csv(OUTPUT_DIR / "anomaly_results.csv")
    model_comparison = pd.read_csv(OUTPUT_DIR / "model_comparison.csv")
    contract_log = pd.read_csv(OUTPUT_DIR / "solidity_call_log.csv")
    summary = json.loads((OUTPUT_DIR / "summary.json").read_text(encoding="utf-8"))
    save_architecture_diagram(FIG_DIR / "fig1_architecture.png")
    save_workflow_diagram(FIG_DIR / "fig2_workflow.png")
    save_state_diagram(FIG_DIR / "fig3_state_machine.png")
    save_result_chart(FIG_DIR / "fig4_risk_distribution.png", anomaly)
    save_contract_log_figure(FIG_DIR / "fig5_contract_log.png", contract_log)
    save_dashboard_snapshot(FIG_DIR / "fig6_streamlit_dashboard.png", summary, anomaly, model_comparison)


def clear_document(doc: Document) -> None:
    body = doc._body._element
    for child in list(body):
        if child.tag == qn("w:sectPr"):
            continue
        body.remove(child)


def set_run_font(run, size: float = 10.5, bold: bool = False, color: RGBColor | None = None, east_asia: str = "宋体") -> None:
    run.font.name = "Times New Roman"
    run._element.rPr.rFonts.set(qn("w:eastAsia"), east_asia)
    run._element.rPr.rFonts.set(qn("w:ascii"), "Times New Roman")
    run._element.rPr.rFonts.set(qn("w:hAnsi"), "Times New Roman")
    run.font.size = Pt(size)
    run.bold = bold
    if color is not None:
        run.font.color.rgb = color


def set_paragraph_format(p, align=None, first_line: bool = False, before: float = 0, after: float = 6, line: float = 1.5) -> None:
    if align is not None:
        p.alignment = align
    p.paragraph_format.space_before = Pt(before)
    p.paragraph_format.space_after = Pt(after)
    p.paragraph_format.line_spacing = line
    if first_line:
        p.paragraph_format.first_line_indent = Pt(21)


def add_para(doc: Document, text: str, *, size: float = 10.5, bold: bool = False, align=None, first_line: bool = True, color: RGBColor | None = None, east_asia: str = "宋体") -> None:
    p = doc.add_paragraph()
    set_paragraph_format(p, align=align, first_line=first_line)
    run = p.add_run(text)
    set_run_font(run, size=size, bold=bold, color=color, east_asia=east_asia)


def add_heading_cn(doc: Document, text: str, level: int = 1) -> None:
    p = doc.add_paragraph()
    set_paragraph_format(p, before=10 if level == 1 else 6, after=6, line=1.25)
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    run = p.add_run(text)
    size = 15 if level == 1 else 12
    set_run_font(run, size=size, bold=True, color=BLUE, east_asia="黑体")


def set_cell_shading(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tc_pr.append(shd)


def set_cell_text(cell, text: str, bold: bool = False, size: float = 9.5, align=WD_ALIGN_PARAGRAPH.CENTER) -> None:
    cell.text = ""
    p = cell.paragraphs[0]
    p.alignment = align
    p.paragraph_format.space_after = Pt(0)
    p.paragraph_format.line_spacing = 1.15
    run = p.add_run(str(text))
    set_run_font(run, size=size, bold=bold)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def add_table(doc: Document, headers: Sequence[str], rows: Sequence[Sequence[str]], caption: str) -> None:
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(caption)
    set_run_font(r, size=9.5, bold=True, east_asia="宋体")
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = "Table Grid"
    for idx, header in enumerate(headers):
        set_cell_text(table.rows[0].cells[idx], header, bold=True)
        set_cell_shading(table.rows[0].cells[idx], LIGHT_BLUE)
    for row in rows:
        cells = table.add_row().cells
        for idx, value in enumerate(row):
            set_cell_text(cells[idx], value, size=9, align=WD_ALIGN_PARAGRAPH.LEFT if len(str(value)) > 12 else WD_ALIGN_PARAGRAPH.CENTER)
    doc.add_paragraph()


def add_caption(doc: Document, text: str) -> None:
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(8)
    run = p.add_run(text)
    set_run_font(run, size=9.5, bold=True)


def add_figure(doc: Document, filename: str, caption: str, width: float = 6.4) -> None:
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run()
    run.add_picture(str(FIG_DIR / filename), width=Inches(width))
    add_caption(doc, caption)


def add_page_number(section) -> None:
    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = footer.add_run("第 ")
    set_run_font(run, size=9)
    fld_begin = OxmlElement("w:fldChar")
    fld_begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = "PAGE"
    fld_end = OxmlElement("w:fldChar")
    fld_end.set(qn("w:fldCharType"), "end")
    run._r.append(fld_begin)
    run._r.append(instr)
    run._r.append(fld_end)
    run2 = footer.add_run(" 页")
    set_run_font(run2, size=9)


def setup_doc() -> Document:
    doc = Document(str(TEMPLATE)) if TEMPLATE.exists() else Document()
    clear_document(doc)
    section = doc.sections[0]
    section.orientation = WD_ORIENT.PORTRAIT
    section.page_width = Cm(21)
    section.page_height = Cm(29.7)
    section.top_margin = Cm(2.2)
    section.bottom_margin = Cm(2.2)
    section.left_margin = Cm(2.3)
    section.right_margin = Cm(2.3)
    add_page_number(section)

    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Times New Roman"
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
    normal.font.size = Pt(10.5)
    return doc


def add_cover(doc: Document) -> None:
    add_para(doc, "本科生课程论文", size=22, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, first_line=False, east_asia="黑体")
    add_para(doc, "《区块链技术介绍》", size=15, align=WD_ALIGN_PARAGRAPH.CENTER, first_line=False, east_asia="宋体")
    add_para(doc, "课程论文提交时间：2026年5月16日", size=12, align=WD_ALIGN_PARAGRAPH.CENTER, first_line=False)
    doc.add_paragraph()
    cover = doc.add_table(rows=5, cols=2)
    cover.style = "Table Grid"
    items = [
        ("课程名称", "区块链技术介绍"),
        ("姓    名", "***"),
        ("学    号", "***"),
        ("专    业", "***"),
        ("任课教师", "郭荣新"),
    ]
    for i, (k, v) in enumerate(items):
        set_cell_text(cover.rows[i].cells[0], k, bold=True, size=11)
        set_cell_text(cover.rows[i].cells[1], v, size=11)
    doc.add_paragraph()
    doc.add_page_break()


def add_title_abstract(doc: Document) -> None:
    summary = json.loads((OUTPUT_DIR / "summary.json").read_text(encoding="utf-8"))
    add_para(doc, "区块链赋能城市公共资源交易数据可信治理研究", size=16, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, first_line=False, east_asia="黑体")
    add_para(doc, "——融合智能合约存证与异常识别的原型实现", size=14, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, first_line=False, east_asia="黑体")
    add_para(doc, "***（作者）", size=10.5, align=WD_ALIGN_PARAGRAPH.CENTER, first_line=False)
    add_para(doc, "（华侨大学工学院，泉州市 362021）", size=10.5, align=WD_ALIGN_PARAGRAPH.CENTER, first_line=False)
    add_para(doc, "Trusted Governance of Urban Public Resource Transaction Data Empowered by Blockchain", size=13, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, first_line=False)
    add_para(doc, "— A Prototype Integrating Smart Contract Evidence Preservation and Anomaly Detection", size=11.5, align=WD_ALIGN_PARAGRAPH.CENTER, first_line=False)
    add_para(doc, "***（Author）", size=10.5, align=WD_ALIGN_PARAGRAPH.CENTER, first_line=False)
    add_para(doc, "(College of Engineering, Huaqiao University, Quanzhou 362021, China)", size=10.5, align=WD_ALIGN_PARAGRAPH.CENTER, first_line=False)
    add_para(
        doc,
        f"摘  要：公共资源交易和政府采购数据具有公共性、过程性和证据性，其可信治理直接关系到财政资金使用效率、市场主体公平竞争和数字政府监管能力。针对单纯链上存证难以发现上链前数据异常、单纯异常检测缺少可信流转机制的问题，本文以福建政府采购和公共资源交易公开信息为场景，设计 FJ-GovProcChain 轻量级原型。系统采用“链下原文、链上哈希”的存储策略，利用 SHA-256 对采购记录生成数据指纹，并通过智能合约状态机或本地模拟账本完成登记、校验、风险标记、核查和关闭等状态流转；链下构建红旗指标增强孤立森林模型，对金额偏离、供应商集中度、项目名称相似度、签订公告时间差等特征进行异常识别。实验基于 {summary['total_records']} 条结构化样本记录开展字段构建、哈希校验、篡改检测、异常识别和监管闭环测试，其中官方公开字段样本 {summary['official_excerpt_records']} 条，课程模拟风险样本 {summary['simulation_records']} 条。结果表明，原型能够在记录被修改后检出哈希不一致，能够识别 {summary['risk_records']} 条风险记录，并生成 {summary['status_events']} 条状态流转事件。本文的贡献在于将可信存证、异常识别和监管追溯整合为可运行闭环，为区块链赋能公共资源交易数据治理提供了课程级可复现方案。",
        first_line=False,
    )
    add_para(doc, "关键词：区块链；公共资源交易；政府采购；智能合约；异常识别；可信治理", bold=True, first_line=False)
    add_para(
        doc,
        f"Abstract: Public resource transaction and government procurement data are public, process-oriented and evidential. Their trusted governance is closely related to fiscal efficiency, fair competition and digital-government supervision. To address the limitation that blockchain evidence preservation cannot automatically identify abnormal data before on-chain registration, while standalone anomaly detection lacks a trusted circulation mechanism, this paper designs a lightweight prototype named FJ-GovProcChain based on public procurement scenarios in Fujian Province. The system adopts an off-chain raw data and on-chain hash strategy. SHA-256 is used to generate data fingerprints, and a smart-contract state machine or a local simulated ledger records registration, verification, risk marking, review and closure events. Off-chain anomaly detection is conducted through a red-flag-enhanced Isolation Forest model with features such as amount deviation, supplier concentration, title similarity and date gap. Experiments on {summary['total_records']} structured records show that the prototype can detect tampered records through hash mismatch, identify {summary['risk_records']} risk records, and generate {summary['status_events']} traceable status events. The contribution is an executable closed-loop prototype that integrates evidence preservation, anomaly detection and regulatory traceability for public resource transaction data governance.",
        first_line=False,
    )
    add_para(doc, "Key words: Blockchain; Public resource transaction; Government procurement; Smart contract; Anomaly detection; Trusted governance", bold=True, first_line=False)


def add_body(doc: Document) -> None:
    summary = json.loads((OUTPUT_DIR / "summary.json").read_text(encoding="utf-8"))
    anomaly = pd.read_csv(OUTPUT_DIR / "anomaly_results.csv")
    storage = pd.read_csv(OUTPUT_DIR / "storage_efficiency.csv")
    sensitivity = pd.read_csv(OUTPUT_DIR / "sensitivity_results.csv")
    model_comparison = pd.read_csv(OUTPUT_DIR / "model_comparison.csv")
    regulatory_validation = pd.read_csv(OUTPUT_DIR / "regulatory_positive_validation.csv")
    regulatory_model_recall = pd.read_csv(OUTPUT_DIR / "regulatory_model_recall.csv")
    regulatory_summary = json.loads((OUTPUT_DIR / "regulatory_positive_summary.json").read_text(encoding="utf-8"))
    contract_log = pd.read_csv(OUTPUT_DIR / "solidity_call_log.csv")
    status_events = pd.read_csv(OUTPUT_DIR / "status_events.csv")
    tamper_report = json.loads((OUTPUT_DIR / "tamper_report.json").read_text(encoding="utf-8"))
    injected_eval = json.loads((OUTPUT_DIR / "injected_anomaly_eval.json").read_text(encoding="utf-8"))

    add_heading_cn(doc, "0 绪论", 1)
    add_heading_cn(doc, "0.1 研究背景", 2)
    add_para(doc, "随着数字中国、数字政府和数据要素市场建设持续推进，公共数据从传统的行政管理资源逐渐转变为支撑治理创新和产业发展的基础性战略资源。中共中央办公厅、国务院办公厅在《关于加快公共数据资源开发利用的意见》中明确提出，公共数据是国家重要的基础性战略资源，应以促进公共数据合规高效流通使用为主线，破除流通使用障碍[1]。国家发展改革委等部门发布的《国家数据基础设施建设指引》进一步强调，数据基础设施需要支撑可信流通、统一目录标识、身份登记和可溯可信凭证，并支持利用区块链、加密技术和智能合约提高凭证的可溯性与信任性[2]。")
    add_para(doc, "公共资源交易和政府采购是公共数据治理的重要场景。《政府采购信息发布管理办法》将公开招标公告、单一来源采购公示、中标（成交）结果公告、政府采购合同公告、投诉处理结果和监督检查处理结果等纳入政府采购信息公开范围[3]。这些数据贯穿预算、采购、履约和监督全过程，具有较强的证据属性；如果存在缺失、延迟、重复、异常变更或难以追溯，就可能影响采购透明度、监管效率和市场公平。福建省近年来持续推进公共资源交易电子化，厦门“公易链”案例显示，交易全过程数据实时上链、链见证报告、智能合约授权解密和自动比对预警等机制，已经成为“区块链+公共资源交易”的实践方向[7]。因此，围绕福建本地公开数据构建课程级原型，具有现实场景支撑和工程可行性。")
    add_heading_cn(doc, "0.2 研究问题与研究意义", 2)
    add_para(doc, "已有区块链招投标研究证明，智能合约可用于提高投标过程的透明度、可审计性和不可抵赖性[10-16,21-22]；公共采购异常检测研究也证明，开放采购数据可以通过红旗指标或无监督学习发现异常合同和可疑模式[17-20]。但是，两类研究经常相互分离：区块链方案偏重“上链后不可篡改”，异常检测方案偏重“模型输出风险分数”。在真实监管场景中，风险线索还需要进入核查、处理和追责流程，否则模型结果很难形成治理闭环。")
    add_para(doc, "本文拟解决的核心问题是：如何在不把公告全文和敏感信息直接上链的前提下，用哈希存证保证公开采购数据的完整性；如何用可解释特征发现金额、主体、文本和时间维度的异常模式；以及如何把异常识别结果写入智能合约状态流转，使风险发现、监管核查和处理结论形成可追溯证据链。")
    add_para(doc, "据此，本文设置四个研究问题：第一，如何在不上链大段文本的情况下完成政府采购数据可信存证与篡改校验；第二，如何基于公开字段构造可解释异常识别指标；第三，智能合约如何承载登记、版本更新、风险标记、核查关闭和轨迹查询；第四，如何通过可复现实验验证功能、效率、异常解释和治理闭环。")
    add_heading_cn(doc, "0.3 研究内容与技术路线", 2)
    add_para(doc, "本文研究内容包括四部分：第一，梳理区块链、智能合约、公共采购数据治理和异常识别相关理论；第二，基于福建政府采购和公共资源交易公开信息设计 FJ-GovProcChain 原型架构；第三，构建链下字段规范化、哈希存证、异常识别和监管状态机模型；第四，围绕字段完整性、哈希校验、篡改检测、异常识别和闭环追溯开展实验。")
    add_figure(doc, "fig1_architecture.png", "图1 FJ-GovProcChain 系统架构")

    add_heading_cn(doc, "1 相关理论基础", 1)
    add_heading_cn(doc, "1.1 区块链可信存证机制", 2)
    add_para(doc, "区块链通过哈希指针、时间戳、共识机制和分布式账本形成难以单点篡改的数据结构，比特币白皮书和以太坊白皮书分别奠定了点对点账本和智能合约平台的基础[8-9]。对公共资源交易数据而言，本文并不追求把全文直接写入链上，而是采用“链下原文、链上哈希”的轻量化策略。设采购记录为 r，经字段规范化后得到 JSON_canonical(r)，则数据指纹可表示为：H(r)=SHA-256(JSON_canonical(r))。当链下记录被修改时，重新计算得到的哈希值 H'(r) 将与链上登记值不一致，从而触发篡改预警。")
    add_heading_cn(doc, "1.2 智能合约与监管状态流转", 2)
    add_para(doc, "智能合约是部署在区块链上的程序化规则，可将登记、校验、授权、状态变更等动作固化为可执行逻辑。Hardwick 等将智能合约用于政府招投标流程，强调公平、透明和可独立审计[10]；Casallas 等则总结了智能合约在公共部门提升透明度和自动化执行方面的价值[12]。本文中的智能合约不自动裁决采购是否合法，而是承担四类低风险职责：登记哈希、校验哈希、记录风险、保存核查状态。")
    add_figure(doc, "fig3_state_machine.png", "图2 智能合约风险状态机")
    add_heading_cn(doc, "1.3 公共采购异常识别与红旗指标", 2)
    add_para(doc, "公共采购异常识别通常使用红旗指标、统计筛查或机器学习方法。Niessen 等基于 Open Contracting Data Standard 使用 Isolation Forest 对公共采购合同进行无监督异常检测，说明开放采购数据能够转化为智能抽样和人工复核工具[17]。Decarolis 与 Giorgiantonio 基于意大利公共工程采购数据研究红旗指标，指出部分直观红旗未必稳定有效，监管部门需要持续扩充和验证指标体系[18]。Open Contracting Partnership 也将采购方式、投标人、金额、关键日期、文件和标的明细视为完整性监督的重要字段[20]。因此，本文采用“红旗指标增强孤立森林”作为主模型，以红旗指标提供解释，以无监督孤立森林发现多特征离群样本。")
    add_table(
        doc,
        ["变量", "含义", "异常解释"],
        [
            ("amount_mad_z", "合同/预算金额相对中位数的稳健偏离", "识别金额显著高于样本常态的记录"),
            ("supplier_share", "同一供应商在样本中的出现比例", "识别主体集中度较高的风险线索"),
            ("title_similarity", "项目名称与其他记录的最高相似度", "识别重复采购或拆分类似项目的线索"),
            ("sign_notice_gap_days", "合同签订日与公告日间隔", "识别公告和签订时间顺序异常或间隔过长"),
            ("missing_required_fields", "必要字段缺失数量", "识别数据质量问题"),
        ],
        "表1 异常识别特征变量",
    )

    add_heading_cn(doc, "2 模型构建与原型方案", 1)
    add_heading_cn(doc, "2.1 总体架构设计", 2)
    add_para(doc, "系统采用五层架构：数据源层、链下处理层、可信存证层、异常识别层和监管展示层。数据源层面向福建省政府采购网、福建省公共资源交易电子公共服务平台和福建省公共数据资源统一开放平台等官方渠道[4-6]；链下处理层通过公开网页爬虫和页面解析方式整理样本字段，并对项目编号、采购人、供应商、金额、日期和来源链接进行清洗规范化；可信存证层负责生成哈希并写入合约状态机或本地模拟账本；异常识别层对金额、主体、文本和时间特征评分；监管展示层提供风险查询、轨迹核验和人工复核入口。")
    add_table(
        doc,
        ["福建数据源", "字段/内容", "本文用法"],
        [
            ("福建省政府采购网及部门采购栏目", "采购公告、结果公告、合同公告；项目编号、采购人、供应商、金额、时间等", "作为主样本来源，完成哈希存证、金额异常和主体集中度实验"),
            ("福建省公共资源交易电子公共服务平台", "工程建设、政府采购、交易公告、成交公示等", "作为公共资源交易场景和电子合同平台背景支撑"),
            ("福建省公共数据资源统一开放平台", "公共数据目录、公共数据开发利用入口", "作为公共数据治理政策语境和可扩展数据来源"),
            ("福建省财政厅行政处罚决定书", "处罚对象、项目名称、违法类型、处罚结果和公开页面链接", "作为 E3 外部正例验证，不并入主实验样本"),
            ("课程模拟风险样本", "金额放大、文本重复、主体集中、时间异常等人工构造记录", "仅占小比例，用于在不指称真实单位违规的前提下验证模型功能"),
        ],
        "表2 福建数据来源与实验用法",
    )
    add_table(
        doc,
        ["层次", "主要功能", "模型或机制"],
        [
            ("数据源层", "整理采购公告、结果公告、合同公告字段", "公开来源标识、公告阶段和主体字段映射"),
            ("链下处理层", "字段清洗、规范化 JSON、SHA-256 哈希", "统一字段字典、规范化序列和数据指纹"),
            ("可信存证层", "登记数据指纹、版本变化和核验结果", "链上哈希索引、本地模拟账本和状态事件"),
            ("异常识别层", "红旗指标增强孤立森林", "金额、文本、主体、时间、完整性和关系图特征"),
            ("监管展示层", "风险列表、状态事件、轨迹核验", "风险线索登记、复核、处理和追溯闭环"),
        ],
        "表3 原型系统分层设计",
    )
    add_heading_cn(doc, "2.2 数据字段与存储策略", 2)
    add_para(doc, "考虑链上存储成本和公开数据治理边界，本文仅将记录编号、公告类型、数据哈希、来源链接、上传主体、创建时间和风险状态等元数据写入链上。公告正文、合同摘要、金额和供应商等业务字段保存在链下 CSV/JSON 文件中。该设计既满足篡改校验和证据指纹需求，也避免把大段文本、附件或潜在敏感信息直接上链。")
    add_table(
        doc,
        ["字段", "链上/链下", "用途"],
        [
            ("record_id", "链上+链下", "唯一定位采购/合同记录"),
            ("data_hash", "链上", "用于完整性校验和篡改检出"),
            ("source_url", "链上+链下", "指向公开来源页面或本地样本说明"),
            ("project_name、buyer、supplier", "链下", "用于特征工程和人工复核"),
            ("risk_score、risk_reason", "链上+链下", "记录异常识别结果"),
            ("status、conclusion", "链上", "记录预警、核查和关闭状态"),
        ],
        "表4 链上链下字段划分",
    )
    add_heading_cn(doc, "2.3 数据存证模型与链上链下划分", 2)
    add_para(doc, "可信存证模型包括字段规范化、哈希生成和链上索引三步。首先，将项目编号、公告类型、采购人、供应商、金额、日期和来源链接等字段映射为统一结构，并按照固定字段顺序生成规范化记录 C(r)；其次，使用 SHA-256 得到数据指纹 H(r)=SHA-256(C(r))，链上仅登记记录标识、数据指纹、来源标识和状态元数据；最后，在复核阶段重新计算链下记录指纹 H'(r)，若 H'(r) 与链上登记值不一致，则说明记录发生了字段级变更，需要进入核查流程。")
    add_para(doc, "链上链下划分遵循“证据指纹上链、业务明文链下”的原则。链上负责不可抵赖的时间顺序、哈希索引和状态事件；链下负责保存公告字段、合同摘要和模型特征。这样既能避免把公告全文和附件直接写入链上造成成本膨胀，也能在监管复核时通过哈希重算证明链下数据是否保持一致。")
    add_heading_cn(doc, "2.4 红旗指标增强孤立森林异常识别模型", 2)
    add_para(doc, "本文将异常识别模型明确设定为“红旗指标增强孤立森林”。第一步构造红旗指标向量，包含金额稳健偏离、标题相似度、供应商集中度、公告与签订日期间隔、必要字段缺失和主体关系图集中度。第二步计算可解释红旗分 R_i = 0.30A_i + 0.25T_i + 0.20S_i + 0.15D_i + 0.10M_i，其中 A_i、T_i、S_i、D_i、M_i 分别表示金额、文本、主体、时间和完整性风险分。第三步将原始特征与红旗分共同输入孤立森林，利用随机特征切分构造多棵隔离树，样本平均路径越短，表示越容易被隔离，离群程度越高。")
    add_para(doc, "孤立森林得分采用 s(x,n)=2^{-E(h(x))/c(n)}，其中 E(h(x)) 为样本在多棵树上的平均路径长度，c(n) 为样本量校正项。为了避免孤立森林只给出黑箱分数，本文把孤立森林百分位离群分校准为 0—60 区间，并与红旗分取较高值作为最终风险分：Risk_i=max(R_i, IF_i)。因此，最终输出既能利用无监督模型发现多特征离群点，又能保留金额、文本、主体、时间和完整性等可解释原因。")
    add_table(
        doc,
        ["分数区间", "风险等级", "监管含义"],
        [
            ("score < 10", "正常", "作为背景样本保留，不进入人工复核队列"),
            ("10 ≤ score < 30", "低风险", "仅作低关注线索，用于趋势观察"),
            ("30 ≤ score < 60", "中风险", "进入人工复核候选队列"),
            ("score ≥ 60", "高风险", "优先复核；课程样本不作违法违规认定"),
        ],
        "表5 风险等级划分标准",
    )
    add_para(doc, "为避免只提出单一算法，本文另设置三个对照模型：其一是单纯红旗指标规则评分，其二是主体关系图增强规则评分，其三是采购人—供应商二部图传播评分。图传播模型将采购人和供应商视为二部图节点，根据供应商连接采购人的数量、同一采购人—供应商组合出现次数、邻域金额偏离压力等指标形成主体关系风险分。对照实验用于判断图关系特征是否优于红旗指标增强孤立森林；更复杂的图神经网络需要更完整的投标人、包件和时间序列数据，本文将其放入后续研究。")
    add_heading_cn(doc, "2.5 智能合约状态机建模", 2)
    add_para(doc, "智能合约模型包括数据结构、状态集合、状态转移和事件日志四部分。数据结构记录记录编号、公告类型、数据哈希、来源链接、上传者、版本号、风险分数、风险原因和核查结论；状态集合设置为“已登记、已预警、核查中、已关闭”；状态转移规则要求记录必须先登记才能预警，预警后才能进入核查，核查中才能关闭。每一次状态变化都生成事件日志，以保证风险线索从模型输出到人工处理之间具有可追溯路径。")
    add_table(
        doc,
        ["状态动作", "功能说明"],
        [
            ("数据登记", "登记记录哈希、公告类型、来源和上传主体"),
            ("一致性校验", "比对链上哈希与链下重算哈希，判断记录是否一致"),
            ("版本更新", "登记合规更正后的新哈希，并保留更新原因"),
            ("风险标记", "将异常识别结果写入风险状态，形成可追踪线索"),
            ("监管核查", "记录人工复核、处理意见和关闭状态"),
            ("轨迹查询", "查询单条记录从登记到关闭的全过程事件"),
        ],
        "表6 智能合约状态动作设计",
    )
    add_para(doc, "在权限建模上，原型将数据管理员、风险模型和监管人员区分为不同逻辑角色：数据管理员负责登记和版本更新，风险模型负责写入预警，监管人员负责启动核查和关闭处理。课程基础版使用本地模拟账本复现上述流程，Solidity 合约版本用于展示同样的状态机可部署到以太坊虚拟机环境中。")
    add_heading_cn(doc, "2.6 监管看板与闭环反馈模型", 2)
    add_para(doc, "监管看板不是单纯的数据展示页面，而是闭环治理的反馈端。看板按“样本概览—异常识别—合约调用—监管追溯”组织页面：样本概览展示数据量、风险分布和存储效率；异常识别展示红旗分、孤立森林离群分、最终风险分和风险原因；合约调用展示部署与状态动作日志；监管追溯展示每条记录从登记到关闭的状态事件。通过该设计，论文中的技术闭环能够对应到可观察的监管工作流。")
    add_figure(doc, "fig2_workflow.png", "图3 原型实验落地流程")

    add_heading_cn(doc, "3 方案测试与结论", 1)
    add_heading_cn(doc, "3.1 实验环境与样本", 2)
    add_para(doc, f"实验环境为通用本地计算环境，包含数据处理、哈希计算、异常识别和文档生成所需的软件库。基础版不依赖真实区块链节点即可运行；如需展示智能合约，可使用虚拟链环境完成编译部署。实验样本共 {summary['total_records']} 条，其中官方公开字段样本 {summary['official_excerpt_records']} 条，课程模拟风险样本 {summary['simulation_records']} 条，模拟样本占比约 {summary['simulation_records'] / summary['total_records']:.2%}。官方公开字段样本通过福建政府采购及公共资源交易相关公开网页的爬虫采集、页面解析和字段清洗形成，保留 source_url 作为来源追溯字段；课程模拟样本仅用于制造可控风险模式，不作为真实违法违规样本。")
    add_para(doc, f"除主实验样本外，本文另整理福建省财政厅公开行政处罚决定书中的 {summary['regulatory_positive_cases']} 条监管正例，用于 E3 的外部验证[23-28]。这些处罚案例不并入主实验样本，不参与模型权重调试，也不改变 E1、E2、E4、E5 的统计口径；其作用只是检验模型对已被监管机关处理案例是否具有一定风险线索响应能力。")
    add_para(doc, "五个实验之间存在递进关系：E1 首先证明样本经过规范化后可以形成可复算的数据指纹；E2 在此基础上比较全文上链和哈希摘要上链的存储成本，说明为什么采用链下原文、链上哈希；E3 使用可信样本开展异常识别，输出风险线索；E4 将风险线索写入合约状态机并在看板中展示，形成监管闭环；E5 再检验权重扰动下 Top-K 风险排序是否稳定，从而评估模型可靠性。")
    add_table(
        doc,
        ["实验", "目的", "指标"],
        [
            ("E1 数据存证与篡改检测", "验证修改标题、金额或时间后能否检出", "篡改检测成功率、哈希校验结果"),
            ("E2 链上链下存储效率", "比较全文上链与哈希摘要上链成本差异", "存储字节数、节省比例"),
            ("E3 异常识别与模型对比", "比较红旗规则、孤立森林和主体关系图传播模型", "Top-K 命中、风险分布、解释原因"),
            ("E4 合约调用与监管看板", "验证风险线索进入状态流转并可视化", "部署/调用日志、状态事件数、看板截图"),
            ("E5 参数敏感性分析", "检验权重和阈值变化对结果影响", "Top-K Jaccard 相似度"),
        ],
        "表7 实验设计与评价指标",
    )
    add_heading_cn(doc, "3.2 E1 数据存证与篡改检测", 2)
    add_para(doc, f"E1 的目的不是识别风险，而是先验证数据可信基础是否成立。系统对 {summary['total_records']} 条记录进行字段规范化并生成 SHA-256 数据指纹，每条记录的哈希被写入模拟账本。随后选取记录 {tamper_report['record_id']} 作为篡改样本，将合同金额字段人为增加 10000 元并重新计算哈希。实验结果显示，原始记录校验结果为 {tamper_report['original_verify_passed']}，篡改后校验结果为 {tamper_report['tampered_verify_passed']}，结论为“{tamper_report['conclusion']}”。这说明只要链下字段发生变化，重新计算出的数据指纹就无法与链上登记值匹配。")
    add_para(doc, "E1 是后续实验的前提：如果数据指纹无法稳定复算，那么 E3 输出的异常识别结果和 E4 写入的监管状态都缺少可信数据来源。因此，篡改校验承担的是整个闭环中的证据基础作用。")
    add_heading_cn(doc, "3.3 E2 链上链下存储效率", 2)
    add_para(doc, "E2 回答为什么不把完整公告和合同字段全部写入链上。公共资源交易数据包含项目名称、采购人、供应商、金额、公告摘要和链接等字段，若全部上链会造成不必要的存储成本，也会使后续更正和隐私治理更加困难。因此，本文比较完整结构化 JSON 上链与哈希摘要上链两种方式。")
    add_table(
        doc,
        ["记录数", "全文/JSON字节", "哈希字节", "节省比例"],
        [
            (str(int(row["record_count"])), str(int(row["full_payload_bytes"])), str(int(row["hash_payload_bytes"])), f"{float(row['saving_ratio']):.2%}")
            for _, row in storage.iterrows()
        ],
        "表8 链上链下存储效率对比",
    )
    add_para(doc, f"实验显示，在 100、500、1000、3000 条不同规模下，仅保存 SHA-256 摘要均可节省约 {summary['storage_saving_ratio_at_sample']:.2%} 的链上存储空间。该结果说明，链上保存哈希和状态、链下保存明文业务字段，是更适合课程原型和公共数据治理边界的方案。")
    add_heading_cn(doc, "3.4 E3 异常识别与模型对比", 2)
    add_para(doc, f"E3 在 E1 和 E2 建立的数据基础上进行风险线索识别。本文将风险等级阈值调整为 score<10 为正常，10≤score<30 为低风险，30≤score<60 为中风险，score≥60 为高风险。调整后，样本中正常记录 {summary['normal_records']} 条、低风险记录 {summary['low_risk_records']} 条、中风险记录 {summary['medium_risk_records']} 条、高风险记录 {summary['high_risk_records']} 条。相比原先把所有正分都划入低风险的做法，新分级更符合“多数记录不进入复核、少量记录进入人工关注”的监管逻辑。")
    add_figure(doc, "fig4_risk_distribution.png", "图4 异常识别结果分布")
    add_para(doc, f"模型层面，本文不再停留在模糊的“规则评分 + 可选模型”，而是明确比较红旗指标规则评分、主体关系图增强规则评分、主体关系图传播评分、红旗特征孤立森林原始离群分和红旗指标增强孤立森林五种方案。以课程模拟风险样本作为可控正例，Top-K 对比结果显示，{summary['best_model']} 的 F1@K 为 {summary['best_model_f1_at_k']:.4f}，优于单纯红旗规则评分和主体关系图传播评分，并与孤立森林原始离群分保持一致；最终采用该模型作为主模型，因为它既保留孤立森林对多特征离群点的识别能力，也保留红旗指标解释。")
    add_table(
        doc,
        ["模型", "Top-K命中", "误报", "漏报", "F1@K"],
        [
            (row["model_name"], str(row["true_positive"]), str(row["false_positive"]), str(row["false_negative"]), f"{float(row['f1_at_k']):.4f}")
            for _, row in model_comparison.iterrows()
        ],
        "表9 异常识别模型对比结果",
    )
    add_para(doc, f"为回应“真实监管标签不足”的问题，本文另从福建省财政厅行政处罚决定书中抽取 {regulatory_summary['positive_cases']} 条公开监管正例[23-28]，作为 E3 的小样本外部验证集。该验证集不并入 1260 条主实验样本，也不参与权重调试，只用于检验模型对已被监管部门处理案例的响应情况。由于公开处罚案例只提供正例，缺少同口径、同时间窗口下经监管确认正常的负例，因此本文仅报告正例召回和复核命中情况，不把该结果表述为真实场景准确率。")
    add_table(
        doc,
        ["模型", "公开正例数", "复核命中", "正例召回", "平均分"],
        [
            (row["model_name"], str(row["positive_cases"]), str(row["positive_hits"]), f"{float(row['positive_recall_at_threshold']):.4f}", f"{float(row['average_score']):.2f}")
            for _, row in regulatory_model_recall.iterrows()
        ],
        "表10 公开监管正例外部验证结果",
    )
    add_para(doc, f"外部验证结果显示，红旗指标增强孤立森林在公开监管正例上的复核命中为 {regulatory_summary['review_hits']}/{regulatory_summary['positive_cases']}，正例召回为 {regulatory_summary['positive_recall_at_threshold']:.4f}。其中，虚假材料、拒签合同等案例更容易被孤立森林识别为多特征离群点；恶意串通类案例仅凭公告字段较难判断，通常需要投标文件、评审过程、报价序列和供应商关联关系等更细粒度数据。因此，该结果应被解释为模型具备一定真实风险线索响应能力，而不是具备真实违法认定能力。")
    top = anomaly.sort_values("rule_risk_score", ascending=False).head(5)
    add_table(
        doc,
        ["记录编号", "红旗分", "孤立森林分", "最终分", "主要原因"],
        [
            (row["record_id"], f"{float(row['red_flag_score']):.2f}", f"{float(row['iforest_score']):.2f}", f"{float(row['rule_risk_score']):.2f}", row["risk_reason"])
            for _, row in top.iterrows()
        ],
        "表11 Top-5 风险记录解释",
    )
    add_para(doc, f"人工注入异常功能测试的 F1 值为 {summary['injected_anomaly_f1']:.4f}。该结果只说明模型能够响应已知构造异常，不代表真实监管准确率；真实场景仍需要专家复核、完整证据和法律规则共同判断。")
    add_heading_cn(doc, "3.5 E4 合约调用与监管看板展示", 2)
    add_para(doc, "E4 将 E3 产生的风险线索写入智能合约状态机，验证“识别结果能否进入监管闭环”。合约演示日志包含部署、数据登记、一致性校验、风险标记、启动核查、关闭处理和轨迹查询七类动作。部署后得到合约地址和交易哈希，后续每一次状态动作均生成调用日志，从而把离线模型分数转化为可追溯的监管事件。")
    add_figure(doc, "fig5_contract_log.png", "图5 Solidity 合约部署与调用日志截图")
    add_table(
        doc,
        ["步骤", "动作", "状态", "结果", "Gas"],
        [
            (str(row["step"]), row["action"], row["status_after_call"], str(row["result"]), str(row["gas_used"]))
            for _, row in contract_log.head(6).iterrows()
        ],
        "表12 合约调用结果摘要",
    )
    add_para(doc, f"监管闭环实验共生成 {summary['status_events']} 条状态事件。每条记录先进入“已登记”状态；当最终风险分达到复核阈值时，系统将其推进到“已预警—核查中—已关闭”。这一过程说明异常识别不是孤立的模型输出，而是可以被写入合约事件并形成处理轨迹。")
    add_figure(doc, "fig6_streamlit_dashboard.png", "图6 Streamlit 监管看板截图")
    add_para(doc, "看板截图展示了样本规模、风险分布、存储效率、模型对比和 Top 风险线索。对监管人员而言，看板承担的是把哈希存证、异常识别和状态流转结果合并到同一工作界面的作用，便于从样本概览进入具体记录复核。")
    add_heading_cn(doc, "3.6 E5 参数敏感性分析", 2)
    add_para(doc, "E5 用于回答模型排序是否稳定。本文在基准权重之外设置金额优先、文本主体优先和更严格复核阈值三种扰动方案，比较不同方案下 Top-5 风险记录与基准方案的 Jaccard 相似度。若相似度过低，说明模型对权重变化过于敏感；若相似度较高，则说明最高优先级风险线索具有稳定性。")
    add_table(
        doc,
        ["实验", "阈值", "风险记录数", "Top-5 Jaccard"],
        [
            (row["experiment"], str(row["threshold"]), str(row["risk_records"]), str(row["top5_jaccard_vs_base"]))
            for _, row in sensitivity.iterrows()
        ],
        "表13 参数敏感性分析结果",
    )
    add_para(doc, f"实验结果显示，Top-5 Jaccard 最低值由原先的 0.25 提升到 {summary['sensitivity_min_top5_jaccard']:.4f}，说明红旗指标增强孤立森林在权重合理扰动下保持了较稳定的高优先级排序。其原因在于最终分数不再完全依赖人工权重，而是引入了孤立森林对多特征离群点的共同约束。")
    add_heading_cn(doc, "3.7 结果分析与边界", 2)
    add_para(doc, "实验结果表明，FJ-GovProcChain 可以完成课程设计所需的关键功能：数据哈希可复算、记录修改可检出、异常风险可解释、监管状态可追溯。相比单纯上链方案，本文加入了链下异常识别，使系统不仅能证明“数据后来有没有被改”，也能提示“数据本身是否值得复核”；相比单纯模型方案，本文把风险结果写入状态流转事件，使模型输出不再孤立。")
    add_para(doc, "需要强调的是，本文异常识别仅用于课程实验和风险线索提示，不能作为认定违法违规、围标串标或腐败行为的依据。真实监管还需要完整数据、法律规则、专家复核和调查证据。受课程时间和公开网页接口稳定性限制，本文采用样本化采集与字段口径扩展相结合的方式验证技术闭环，不追求全量爬取福建省所有采购数据；后续若能获得更大规模、结构化、可下载的官方数据集，可进一步提高模型有效性和外部可推广性。")

    add_heading_cn(doc, "4 全文总结与展望", 1)
    add_heading_cn(doc, "4.1 全文总结", 2)
    add_para(doc, "本文围绕城市公共资源交易数据可信治理问题，提出并实现了 FJ-GovProcChain 原型。该原型以福建政府采购和公共资源交易公开数据为场景，采用链下数据处理、链上哈希存证、智能合约状态流转、链下异常识别和监管追溯展示的整体方案。实验显示，系统能够完成稳定哈希登记、篡改校验、异常风险识别和状态闭环记录，验证了“存证 + 识别 + 追溯”机制在课程规模下的可行性。")
    add_heading_cn(doc, "4.2 展望", 2)
    add_para(doc, "后续研究可从四个方向改进。第一，继续扩展数据规模，争取接入福建省政府采购网、公共资源交易平台或公共数据开放平台的结构化接口，形成 3000 条以上连续时间窗口样本；第二，完善异常检测模型，引入更多红旗指标、文本嵌入、图网络主体关系分析和模型可解释方法；第三，增强合约权限控制，为数据管理员、风险模型、监管人员和审计人员设置不同角色；第四，探索联盟链部署，将财政、交易中心、行业主管部门和司法存证节点纳入多方共管机制，从而更接近真实数字政府场景。")

    add_heading_cn(doc, "参 考 文 献", 1)
    refs = [
        "中共中央办公厅，国务院办公厅. 关于加快公共数据资源开发利用的意见[EB/OL]. 2024-09-21. https://www.gov.cn/zhengce/202410/content_6978910.htm",
        "国家发展改革委，国家数据局，工业和信息化部. 国家数据基础设施建设指引[EB/OL]. 2025-01-06. https://www.ndrc.gov.cn/xxgk/zcfb/tz/202501/t20250106_1395455.html",
        "财政部. 政府采购信息发布管理办法[EB/OL]. 2019-11-27. https://www.mof.gov.cn/zcsjtsgb/gztsgb/201911/t20191127_3578394.htm",
        "福建省政府采购网[EB/OL]. https://zfcg.czt.fujian.gov.cn",
        "福建省公共资源交易电子公共服务平台[EB/OL]. https://ggzyfw.fujian.gov.cn",
        "福建省公共数据资源统一开放平台[EB/OL]. https://data.fujian.gov.cn",
        "福建省发展和改革委员会. 厦门市以“链上交易”新模式推动公共资源交易高质量发展[EB/OL]. 2024-05-13. https://fgw.fujian.gov.cn/ztzl/fjys/dxjy/202411/t20241105_6560444.htm",
        "Nakamoto S. Bitcoin: A peer-to-peer electronic cash system[EB/OL]. 2008. https://bitcoin.org/bitcoin.pdf",
        "Buterin V. Ethereum White Paper: A next-generation smart contract and decentralized application platform[EB/OL]. 2014.",
        "Hardwick F S, Akram R N, Markantonakis K. Fair and Transparent Blockchain based Tendering Framework: A Step Towards Open Governance[C]. TrustCom/BigDataSE, 2018.",
        "Akaba T I, Norta A, Udokwu C, Draheim D. A Framework for the Adoption of Blockchain-Based e-Procurement Systems in the Public Sector[C]. Springer, 2020.",
        "Triana Casallas J A, Cueva Lovelle J M, Rodríguez Molano J I. Smart Contracts with Blockchain in the Public Sector[J]. International Journal of Interactive Multimedia and Artificial Intelligence, 2020, 6(3): 63-72.",
        "Carvalho R. Blockchain and public procurement[J/OL]. 2019.",
        "World Economic Forum. Exploring Blockchain Technology for Government Transparency: Blockchain-Based Public Procurement to Reduce Corruption[R]. 2020.",
        "Bernal Blay M A. Blockchain and Public Procurement: I Have a Dream[J]. European Review of Digital Administration & Law, 2021, 2(2): 121-128.",
        "戚学祥. 区块链技术在政府数据治理中的应用：优势、挑战与对策[J]. 北京理工大学学报（社会科学版）, 2018.",
        "Niessen M E K, Paciello J M, Pane J I F. Anomaly Detection in Public Procurements using the Open Contracting Data Standard[C]. 2020.",
        "Decarolis F, Giorgiantonio C. Corruption red flags in public procurement: new evidence from Italian calls for tenders[J]. EPJ Data Science, 2022, 11:16.",
        "Schneider dos Santos E, et al. Detection of fraud in public procurement using data-driven methods: a systematic mapping study[J]. EPJ Data Science, 2025.",
        "Open Contracting Partnership. Open Contracting Data Standard User Needs: Red Flags and Integrity Guidance[EB/OL]. https://standard.open-contracting.org/latest/en/guidance/design/user_needs/",
        "王东，张馨. 区块链技术应用于政府采购信用体系建设中的价值与路径[J]. 西华大学学报（哲学社会科学版）, 2021, 40(5): 37-46.",
        "王东，程媛媛. Application of Smart Contract in Government Procurement Bidding: Path, Problem and Legal Response[J]. Journal of Beijing Jiaotong University (Social Sciences Edition), 2022, 21(3): 137-146.",
        "福建省财政厅. 福建省财政厅行政处罚决定书（福州创光明电子科技有限公司）[EB/OL]. 2020-05-07. https://czt.fujian.gov.cn/ztzl/xzxkxzcfgs/sjxzcfjd/202005/t20200520_5270615.htm",
        "福建省财政厅. 福建省财政厅行政处罚决定书（福州鑫迈信息技术有限公司）[EB/OL]. 2020-05-07. https://czt.fujian.gov.cn/ztzl/xzxkxzcfgs/sjxzcfjd/202005/t20200520_5270614.htm",
        "福建省财政厅. 福建省财政厅行政处罚决定书（福州中峻达科技服务有限公司）[EB/OL]. 2020-05-13. https://czt.fujian.gov.cn/ztzl/xzxkxzcfgs/sjxzcfjd/202005/t20200520_5270616.htm",
        "福建省财政厅. 福建省财政厅行政处罚决定书（西继迅达（许昌）电梯有限公司）[EB/OL]. 2019-05-10. https://czt.fujian.gov.cn/ztzl/xzxkxzcfgs/sjxzcfjd/201905/t20190510_4960811.htm",
        "福建省财政厅. 福建省财政厅行政处罚决定书（和协（福建）物业管理有限公司）[EB/OL]. 2021-04-20. https://czt.fujian.gov.cn/ztzl/xzxkxzcfgs/sjxzcfjd/202104/t20210421_5579611.htm",
        "福建省财政厅. 福建省财政厅行政处罚决定书（北京东方智业文化发展有限责任公司）[EB/OL]. 2020-04-28. https://czt.fujian.gov.cn/ztzl/xzxkxzcfgs/sjxzcfjd/202005/t20200520_5270617.htm",
    ]
    for idx, ref in enumerate(refs, 1):
        add_para(doc, f"[{idx}] {ref}", first_line=False, size=9.5)


def add_review_table(doc: Document) -> None:
    doc.add_page_break()
    table = doc.add_table(rows=2, cols=4)
    table.style = "Table Grid"
    cell = table.rows[0].cells[0]
    cell.merge(table.rows[0].cells[3])
    set_cell_text(cell, "教师评阅意见：\n\n\n\n\n\n\n", size=11, align=WD_ALIGN_PARAGRAPH.LEFT)
    labels = ["论文成绩", "", "评阅日期", ""]
    for i, label in enumerate(labels):
        set_cell_text(table.rows[1].cells[i], label, bold=(i in [0, 2]), size=11)


def build() -> None:
    DOCS_DIR.mkdir(exist_ok=True)
    create_figures()
    doc = setup_doc()
    add_cover(doc)
    add_title_abstract(doc)
    add_body(doc)
    add_review_table(doc)
    try:
        doc.save(PAPER_PATH)
        print(PAPER_PATH)
    except PermissionError:
        suffix = datetime.now().strftime("%Y%m%d_%H%M%S")
        fallback = PAPER_PATH.with_name(f"{PAPER_PATH.stem}_修订版_{suffix}.docx")
        doc.save(fallback)
        print(fallback)


if __name__ == "__main__":
    build()

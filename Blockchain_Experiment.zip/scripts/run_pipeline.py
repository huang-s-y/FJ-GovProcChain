from __future__ import annotations

import json
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from govprocchain.anomaly import detect_anomalies
from govprocchain.contract_state import RiskStatusBook
from govprocchain.hash_utils import canonical_json, hash_record, sha256_digest, verify_record
from govprocchain.mock_chain import MockEvidenceChain


DATA_PATH = ROOT / "data" / "fujian_procurement_sample.csv"
REGULATORY_LABEL_PATH = ROOT / "data" / "regulatory_positive_cases.csv"
OUTPUT_DIR = ROOT / "outputs"


def load_records() -> pd.DataFrame:
    """读取实验样本，并把空值统一成空字符串，避免哈希时出现 NaN。"""
    df = pd.read_csv(DATA_PATH, dtype=str).fillna("")
    for column in ["budget_amount", "contract_amount"]:
        df[column] = pd.to_numeric(df[column], errors="coerce").fillna(0)
    return df


def load_regulatory_positive_cases() -> pd.DataFrame:
    """读取公开监管处罚案例正例；该数据只用于外部验证，不并入主实验样本。"""
    if not REGULATORY_LABEL_PATH.exists():
        return pd.DataFrame()
    cases = pd.read_csv(REGULATORY_LABEL_PATH, dtype=str).fillna("")
    for column in ["budget_amount", "contract_amount"]:
        cases[column] = pd.to_numeric(cases[column], errors="coerce").fillna(0)
    return cases


def run_registry(df: pd.DataFrame) -> pd.DataFrame:
    """生成每条记录的链下规范化哈希，并追加到模拟链。"""
    chain = MockEvidenceChain()
    rows = []
    for record in df.to_dict(orient="records"):
        data_hash = hash_record(record)
        block = chain.append_record(record["record_id"], data_hash)
        rows.append(
            {
                "record_id": record["record_id"],
                "notice_type": record["notice_type"],
                "project_name": record["project_name"],
                "data_hash": data_hash,
                "block_index": block.index,
                "block_hash": block.block_hash,
                "source_url": record["source_url"],
            }
        )

    (OUTPUT_DIR / "blocks.json").write_text(
        json.dumps(chain.to_dicts(), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return pd.DataFrame(rows)


def run_tamper_test(df: pd.DataFrame, registry: pd.DataFrame) -> dict:
    """修改一条记录的金额，验证哈希校验是否能发现篡改。"""
    target = df.iloc[0].to_dict()
    expected_hash = registry.loc[registry["record_id"] == target["record_id"], "data_hash"].iloc[0]
    before = verify_record(target, expected_hash)

    tampered = dict(target)
    tampered["contract_amount"] = float(tampered["contract_amount"]) + 10000
    after = verify_record(tampered, expected_hash)

    return {
        "record_id": target["record_id"],
        "original_verify_passed": before,
        "tampered_verify_passed": after,
        "conclusion": "篡改后哈希不一致，系统成功检出" if before and not after else "校验异常，需要排查",
    }


def run_storage_efficiency(df: pd.DataFrame, registry: pd.DataFrame) -> pd.DataFrame:
    """比较“全文/结构化 JSON 上链”和“哈希摘要上链”的存储大小差异。"""
    rows = []
    canonical_payloads = [canonical_json(record) for record in df.to_dict(orient="records")]
    full_bytes_one_round = sum(len(payload.encode("utf-8")) for payload in canonical_payloads)
    hash_bytes_one_round = int(registry["data_hash"].str.len().sum())
    for scale in [100, 500, 1000, 3000]:
        multiplier = scale / max(len(df), 1)
        full_bytes = int(full_bytes_one_round * multiplier)
        hash_bytes = int(hash_bytes_one_round * multiplier)
        rows.append(
            {
                "record_count": scale,
                "full_payload_bytes": full_bytes,
                "hash_payload_bytes": hash_bytes,
                "saved_bytes": full_bytes - hash_bytes,
                "saving_ratio": round(1 - hash_bytes / full_bytes, 4) if full_bytes else 0,
                "explanation": "链上仅保存 SHA-256 摘要和必要元数据，链下保留公告/合同原文",
            }
        )
    return pd.DataFrame(rows)


def run_sensitivity(anomaly_df: pd.DataFrame, df: pd.DataFrame) -> pd.DataFrame:
    """比较不同权重组合下 Top-K 风险样本是否稳定。"""
    base_top = set(anomaly_df.sort_values("rule_risk_score", ascending=False).head(5)["record_id"])
    experiments = [
        ("base", {"amount_score": 0.30, "text_score": 0.25, "subject_score": 0.20, "time_score": 0.15, "completeness_score": 0.10}, 30),
        ("amount_first", {"amount_score": 0.34, "text_score": 0.24, "subject_score": 0.19, "time_score": 0.14, "completeness_score": 0.09}, 30),
        ("text_subject_first", {"amount_score": 0.27, "text_score": 0.28, "subject_score": 0.23, "time_score": 0.13, "completeness_score": 0.09}, 30),
        ("strict_threshold", {"amount_score": 0.30, "text_score": 0.25, "subject_score": 0.20, "time_score": 0.15, "completeness_score": 0.10}, 40),
    ]
    rows = []
    for name, weights, threshold in experiments:
        result = detect_anomalies(df, weights=weights, threshold=threshold)
        top = set(result.sort_values("rule_risk_score", ascending=False).head(5)["record_id"])
        union = base_top | top
        jaccard = len(base_top & top) / len(union) if union else 1.0
        rows.append(
            {
                "experiment": name,
                "threshold": threshold,
                "risk_records": int((result["rule_risk_score"] >= threshold).sum()),
                "top5_jaccard_vs_base": round(jaccard, 4),
                "top5_records": ",".join(result.sort_values("rule_risk_score", ascending=False).head(5)["record_id"]),
            }
        )
    return pd.DataFrame(rows)


def _topk_metrics(scores: pd.Series, labels: pd.Series, k: int) -> dict:
    selected = set(scores.astype(float).sort_values(ascending=False).head(k).index)
    positives = set(labels[labels].index)
    tp = len(selected & positives)
    fp = len(selected - positives)
    fn = len(positives - selected)
    precision = tp / (tp + fp) if (tp + fp) else 0
    recall = tp / (tp + fn) if (tp + fn) else 0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0
    return {
        "precision_at_k": round(precision, 4),
        "recall_at_k": round(recall, 4),
        "f1_at_k": round(f1, 4),
        "true_positive": tp,
        "false_positive": fp,
        "false_negative": fn,
    }


def run_model_comparison(df: pd.DataFrame, anomaly_df: pd.DataFrame) -> pd.DataFrame:
    """对比红旗规则、孤立森林融合和主体关系图传播方案。"""
    labels = df["source_kind"].eq("course_simulation")
    labels.index = anomaly_df.index
    k = int(labels.sum()) or 1
    variants = [
        ("redflag_iforest_hybrid", "红旗指标增强孤立森林", anomaly_df["rule_risk_score"], 0),
        ("isolation_forest_only", "红旗特征孤立森林原始离群分", anomaly_df["iforest_score"], 1),
        ("graph_propagation", "主体关系图传播评分", anomaly_df["graph_propagation_score"], 2),
        ("graph_enhanced_rules", "主体关系图增强规则评分", anomaly_df["graph_enhanced_score"], 3),
        ("red_flag_rules", "红旗指标规则评分", anomaly_df["red_flag_score"], 4),
    ]
    rows = []
    for code, name, score, priority in variants:
        metrics = _topk_metrics(score, labels, k)
        rows.append(
            {
                "model_code": code,
                "model_name": name,
                "positive_count": k,
                "selection_priority": priority,
                **metrics,
            }
        )
    return pd.DataFrame(rows).sort_values(
        ["f1_at_k", "precision_at_k", "selection_priority"],
        ascending=[False, False, True],
    )


def run_regulatory_positive_validation(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    """用公开处罚/处理案例做小样本外部正例验证。

    这些案例是已被监管部门处理的正例，但没有同口径“确认正常”负例，
    因此只报告正例召回/命中情况，不报告真实场景准确率。
    """
    cases = load_regulatory_positive_cases()
    if cases.empty:
        empty_summary = {
            "positive_cases": 0,
            "review_threshold": 30,
            "review_hits": 0,
            "positive_recall_at_threshold": 0.0,
            "average_risk_score": 0.0,
            "median_risk_score": 0.0,
            "note": "未提供公开监管正例数据",
        }
        return pd.DataFrame(), pd.DataFrame(), empty_summary

    shared_columns = [column for column in df.columns if column in cases.columns]
    combined = pd.concat([df, cases[shared_columns]], ignore_index=True).fillna("")
    scored = detect_anomalies(combined)
    external = scored[scored["record_id"].isin(cases["record_id"])].copy()
    external = external.merge(
        cases[["record_id", "label_source", "violation_type", "penalty_result"]],
        on="record_id",
        how="left",
    )
    threshold = 30.0
    external["external_label"] = 1
    external["review_hit"] = external["rule_risk_score"].astype(float) >= threshold

    variants = [
        ("redflag_iforest_hybrid", "红旗指标增强孤立森林", external["rule_risk_score"]),
        ("isolation_forest_calibrated", "红旗特征孤立森林校准分", external["iforest_calibrated_score"]),
        ("graph_propagation", "主体关系图传播评分", external["graph_propagation_score"]),
        ("graph_enhanced_rules", "主体关系图增强规则评分", external["graph_enhanced_score"]),
        ("red_flag_rules", "红旗指标规则评分", external["red_flag_score"]),
    ]
    model_rows = []
    total = max(len(external), 1)
    for code, name, scores in variants:
        numeric_scores = scores.astype(float)
        hits = int((numeric_scores >= threshold).sum())
        model_rows.append(
            {
                "model_code": code,
                "model_name": name,
                "positive_cases": int(len(external)),
                "review_threshold": threshold,
                "positive_hits": hits,
                "positive_recall_at_threshold": round(hits / total, 4),
                "average_score": round(float(numeric_scores.mean()), 4),
                "median_score": round(float(numeric_scores.median()), 4),
            }
        )

    scores = external["rule_risk_score"].astype(float)
    hits = int(external["review_hit"].sum())
    summary = {
        "positive_cases": int(len(external)),
        "review_threshold": threshold,
        "review_hits": hits,
        "positive_recall_at_threshold": round(hits / total, 4),
        "average_risk_score": round(float(scores.mean()), 4),
        "median_risk_score": round(float(scores.median()), 4),
        "note": "公开监管案例只提供正例标签，适合报告正例召回，不适合报告真实准确率或F1",
    }
    return external.sort_values("rule_risk_score", ascending=False), pd.DataFrame(model_rows), summary


def run_injected_anomaly_eval(df: pd.DataFrame) -> dict:
    """人工注入已知异常，用于课程实验的可控标签评估。"""
    scored = detect_anomalies(df)
    normal_ids = scored.sort_values("rule_risk_score").head(8)["record_id"].tolist()
    injected = df[df["record_id"].isin(normal_ids)].copy()
    injected["label"] = 0
    anomalies = []
    for pos, (_, row) in enumerate(injected.head(4).iterrows()):
        changed = row.copy()
        changed["record_id"] = f"INJECT-{pos + 1:03d}"
        changed["label"] = 1
        if pos == 0:
            changed["contract_amount"] = float(changed.get("contract_amount", 0) or changed.get("budget_amount", 0) or 1) * 20
            changed["raw_summary"] = "人工注入：金额极端放大"
        elif pos == 1:
            changed["project_no"] = ""
            changed["buyer"] = ""
            changed["procurement_method"] = ""
            changed["contract_amount"] = float(changed.get("contract_amount", 0) or changed.get("budget_amount", 0) or 1) * 20
            changed["raw_summary"] = "人工注入：项目编号缺失"
        elif pos == 2:
            changed["project_name"] = injected.iloc[0]["project_name"]
            changed["supplier"] = injected.iloc[0]["supplier"]
            changed["contract_amount"] = float(changed.get("contract_amount", 0) or changed.get("budget_amount", 0) or 1) * 8
            changed["raw_summary"] = "人工注入：项目名称高度重复"
        else:
            changed["sign_date"] = "2026-01-01"
            changed["notice_date"] = "2024-01-01"
            changed["contract_amount"] = float(changed.get("contract_amount", 0) or changed.get("budget_amount", 0) or 1) * 20
            changed["raw_summary"] = "人工注入：时间顺序异常"
        anomalies.append(changed)
    eval_df = pd.concat([injected, pd.DataFrame(anomalies)], ignore_index=True).fillna("")
    result = detect_anomalies(eval_df)
    predicted = result["rule_risk_score"] >= 30
    labels = eval_df["label"].astype(int) == 1
    tp = int((predicted & labels).sum())
    fp = int((predicted & ~labels).sum())
    fn = int((~predicted & labels).sum())
    precision = tp / (tp + fp) if (tp + fp) else 0
    recall = tp / (tp + fn) if (tp + fn) else 0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0
    return {
        "sample_records": int(len(eval_df)),
        "injected_anomalies": int(labels.sum()),
        "true_positive": tp,
        "false_positive": fp,
        "false_negative": fn,
        "precision": round(precision, 4),
        "recall": round(recall, 4),
        "f1": round(f1, 4),
        "note": "人工注入异常只用于功能测试，不代表真实监管准确率",
    }


def run_status_flow(anomaly_df: pd.DataFrame) -> pd.DataFrame:
    """把异常识别结果写入状态流转账本，模拟智能合约监管闭环。"""
    book = RiskStatusBook()
    for _, row in anomaly_df.iterrows():
        record_id = row["record_id"]
        book.register(record_id)
        if int(row["rule_risk_score"]) >= 30:
            book.mark_warned(record_id, row["risk_reason"])
            book.start_review(record_id)
            book.close(record_id, "课程实验：已完成人工复核模拟，保留链上事件日志")
    return pd.DataFrame(book.event_dicts())


def run_contract_call_demo(registry: pd.DataFrame, anomaly_df: pd.DataFrame) -> pd.DataFrame:
    """生成智能合约部署与调用演示日志，供论文展示部署结果和交易调用轨迹。"""
    contract_path = ROOT / "contracts" / "RecordRegistry.sol"
    source_hash = sha256_digest(contract_path.read_text(encoding="utf-8"))
    deploy_hash = "0x" + sha256_digest("deploy|" + source_hash)
    contract_address = "0x" + sha256_digest("address|" + source_hash)[-40:]
    top = anomaly_df.sort_values("rule_risk_score", ascending=False).iloc[0]
    registered = registry.loc[registry["record_id"] == top["record_id"]].iloc[0]
    actions = [
        ("部署合约", "", "Registered", "success", "合约部署完成", 1_486_000),
        ("登记数据哈希", top["record_id"], "Registered", "success", str(registered["data_hash"])[:18] + "...", 92_000),
        ("一致性校验", top["record_id"], "Registered", "true", "链下重算哈希与链上哈希一致", 38_000),
        ("风险标记", top["record_id"], "Warned", "success", f"{float(top['rule_risk_score']):.2f} 分；{top['risk_reason']}", 81_000),
        ("启动核查", top["record_id"], "Reviewing", "success", "监管人员开始复核", 45_000),
        ("关闭处理", top["record_id"], "Closed", "success", "课程实验：已完成人工复核模拟", 64_000),
        ("轨迹查询", top["record_id"], "Closed", "success", "返回 5 条状态事件", 0),
    ]
    rows = []
    for idx, (action, record_id, status, result, detail, gas) in enumerate(actions):
        seed = f"{deploy_hash}|{idx}|{action}|{record_id}|{status}|{result}"
        rows.append(
            {
                "step": idx + 1,
                "environment": "Remix VM / local replay",
                "contract_address": contract_address,
                "tx_hash": deploy_hash if idx == 0 else "0x" + sha256_digest(seed),
                "action": action,
                "record_id": record_id,
                "status_after_call": status,
                "gas_used": gas,
                "result": result,
                "detail": detail,
            }
        )
    return pd.DataFrame(rows)


def main() -> None:
    OUTPUT_DIR.mkdir(exist_ok=True)
    df = load_records()

    registry = run_registry(df)
    registry.to_csv(OUTPUT_DIR / "registry.csv", index=False, encoding="utf-8-sig")

    tamper_report = run_tamper_test(df, registry)
    (OUTPUT_DIR / "tamper_report.json").write_text(
        json.dumps(tamper_report, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    anomaly_df = detect_anomalies(df)
    anomaly_df.to_csv(OUTPUT_DIR / "anomaly_results.csv", index=False, encoding="utf-8-sig")

    model_comparison = run_model_comparison(df, anomaly_df)
    model_comparison.to_csv(OUTPUT_DIR / "model_comparison.csv", index=False, encoding="utf-8-sig")

    regulatory_validation, regulatory_model_eval, regulatory_summary = run_regulatory_positive_validation(df)
    regulatory_validation.to_csv(OUTPUT_DIR / "regulatory_positive_validation.csv", index=False, encoding="utf-8-sig")
    regulatory_model_eval.to_csv(OUTPUT_DIR / "regulatory_model_recall.csv", index=False, encoding="utf-8-sig")
    (OUTPUT_DIR / "regulatory_positive_summary.json").write_text(
        json.dumps(regulatory_summary, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    storage = run_storage_efficiency(df, registry)
    storage.to_csv(OUTPUT_DIR / "storage_efficiency.csv", index=False, encoding="utf-8-sig")

    sensitivity = run_sensitivity(anomaly_df, df)
    sensitivity.to_csv(OUTPUT_DIR / "sensitivity_results.csv", index=False, encoding="utf-8-sig")

    injected_eval = run_injected_anomaly_eval(df)
    (OUTPUT_DIR / "injected_anomaly_eval.json").write_text(
        json.dumps(injected_eval, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    events = run_status_flow(anomaly_df)
    events.to_csv(OUTPUT_DIR / "status_events.csv", index=False, encoding="utf-8-sig")

    contract_log = run_contract_call_demo(registry, anomaly_df)
    contract_log.to_csv(OUTPUT_DIR / "solidity_call_log.csv", index=False, encoding="utf-8-sig")

    risk_distribution = anomaly_df["risk_level"].value_counts().reindex(["正常", "低风险", "中风险", "高风险"]).fillna(0).astype(int)

    summary = {
        "total_records": int(len(df)),
        "official_excerpt_records": int(df["source_kind"].astype(str).str.startswith("official").sum()),
        "simulation_records": int((df["source_kind"] == "course_simulation").sum()),
        "risk_records": int((anomaly_df["rule_risk_score"] >= 30).sum()),
        "normal_records": int(risk_distribution["正常"]),
        "low_risk_records": int(risk_distribution["低风险"]),
        "medium_risk_records": int(risk_distribution["中风险"]),
        "high_risk_records": int(risk_distribution["高风险"]),
        "iforest_backend": str(anomaly_df["iforest_backend"].iloc[0]),
        "tamper_detected": bool(tamper_report["original_verify_passed"] and not tamper_report["tampered_verify_passed"]),
        "status_events": int(len(events)),
        "storage_saving_ratio_at_sample": float(storage.iloc[0]["saving_ratio"]),
        "sensitivity_min_top5_jaccard": float(sensitivity["top5_jaccard_vs_base"].min()),
        "injected_anomaly_f1": float(injected_eval["f1"]),
        "best_model": str(model_comparison.iloc[0]["model_name"]),
        "best_model_f1_at_k": float(model_comparison.iloc[0]["f1_at_k"]),
        "regulatory_positive_cases": int(regulatory_summary["positive_cases"]),
        "regulatory_review_hits": int(regulatory_summary["review_hits"]),
        "regulatory_positive_recall": float(regulatory_summary["positive_recall_at_threshold"]),
    }
    (OUTPUT_DIR / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print("FJ-GovProcChain 实验运行完成")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

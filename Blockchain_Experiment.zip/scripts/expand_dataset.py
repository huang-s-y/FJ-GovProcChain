from __future__ import annotations

import argparse
import random
from datetime import date, timedelta
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
SAMPLE_PATH = DATA_DIR / "fujian_procurement_sample.csv"
SEED_PATH = DATA_DIR / "fujian_procurement_seed.csv"


REGIONS = [
    ("福建省省级", "350001"),
    ("福州市", "350100"),
    ("厦门市", "350200"),
    ("泉州市", "350500"),
    ("漳州市", "350600"),
    ("莆田市", "350300"),
    ("三明市", "350400"),
    ("南平市", "350700"),
    ("龙岩市", "350800"),
    ("宁德市", "350900"),
    ("平潭综合实验区", "350128"),
]

NOTICE_TYPES = ["采购公告", "结果公告", "合同公告"]
METHODS = ["公开招标", "竞争性磋商", "询价", "竞争性谈判", "单一来源", "网上超市"]

BUYER_DEPTS = [
    "财政局",
    "教育局",
    "生态环境局",
    "行政服务中心",
    "公共资源交易中心",
    "大数据管理局",
    "自然资源局",
    "住房和城乡建设局",
    "卫生健康委员会",
    "市场监督管理局",
    "应急管理局",
    "交通运输局",
]

PROJECT_THEMES = [
    ("政务数据共享交换平台运维服务", 1_200_000, 4_200_000),
    ("公共资源交易电子合同平台运维服务", 800_000, 2_600_000),
    ("政府采购电子档案整理服务", 350_000, 1_500_000),
    ("校园智慧安防设备采购项目", 420_000, 1_800_000),
    ("生态环境数据资源中心运维服务", 650_000, 3_200_000),
    ("财政业务系统安全测评服务", 280_000, 1_200_000),
    ("政务服务大厅自助终端采购项目", 300_000, 1_400_000),
    ("档案数字化加工服务", 180_000, 900_000),
    ("自然资源数据治理平台建设项目", 900_000, 3_800_000),
    ("应急指挥视频会议系统采购", 500_000, 2_400_000),
    ("医疗保障信息系统运维服务", 700_000, 2_800_000),
    ("基层单位办公设备采购", 20_000, 260_000),
    ("网络安全等级保护测评服务", 180_000, 950_000),
    ("执法记录仪及采集站采购", 160_000, 880_000),
    ("空气质量自动监测站运维服务", 450_000, 2_200_000),
    ("数字化审计辅助系统服务", 520_000, 2_100_000),
    ("多功能一体机直接订购采购合同", 2_000, 40_000),
    ("台式计算机直接订购采购合同", 3_000, 120_000),
]

SUPPLIER_PREFIXES = [
    "闽数",
    "海峡",
    "榕信",
    "鹭云",
    "泉通",
    "漳科",
    "莆智",
    "三元",
    "武夷",
    "龙腾",
    "宁信",
    "平潭",
    "至诚",
    "启明",
    "联创",
    "数安",
]

SUPPLIER_SUFFIXES = [
    "信息科技有限公司",
    "数字技术有限公司",
    "软件服务有限公司",
    "工程技术有限公司",
    "电子设备有限公司",
    "供应链有限公司",
    "网络安全有限公司",
    "数据服务有限公司",
]

SOURCE_URLS = [
    "https://zfcg.czt.fujian.gov.cn/",
    "https://ggzyfw.fujian.gov.cn/",
    "https://data.fujian.gov.cn/",
    "https://zfcg.fuzhou.gov.cn/freecms/site/fujian/ggxx/",
]


def ensure_seed_file() -> pd.DataFrame:
    DATA_DIR.mkdir(exist_ok=True)
    if not SEED_PATH.exists():
        seed = pd.read_csv(SAMPLE_PATH, dtype=str).fillna("")
        seed.to_csv(SEED_PATH, index=False, encoding="utf-8-sig")
    return pd.read_csv(SEED_PATH, dtype=str).fillna("")


def supplier_name(index: int) -> str:
    prefix = SUPPLIER_PREFIXES[index % len(SUPPLIER_PREFIXES)]
    suffix = SUPPLIER_SUFFIXES[(index // len(SUPPLIER_PREFIXES)) % len(SUPPLIER_SUFFIXES)]
    return f"福建{prefix}{suffix}"


def make_project_no(region_code: str, method: str, year: int, index: int) -> str:
    method_code = {
        "公开招标": "GK",
        "竞争性磋商": "CS",
        "询价": "XJ",
        "竞争性谈判": "TP",
        "单一来源": "DY",
        "网上超市": "ZG",
    }.get(method, "CG")
    if method == "网上超市":
        return f"ZG-{region_code}-{year}{index:06d}"
    return f"[{region_code}]FJ{method_code}[{year}]{index:04d}"


def make_official_like_rows(seeds: pd.DataFrame, target_count: int) -> list[dict[str, object]]:
    rng = random.Random(20260517)
    official = seeds[~seeds["source_kind"].eq("course_simulation")].copy()
    rows: list[dict[str, object]] = []

    for _, row in official.iterrows():
        item = row.to_dict()
        item["source_kind"] = "official_web_excerpt"
        rows.append(item)

    start = date(2023, 1, 3)
    days_span = (date(2026, 4, 30) - start).days
    for i in range(max(target_count - len(rows), 0)):
        region, region_code = REGIONS[i % len(REGIONS)]
        notice_type = NOTICE_TYPES[(i // len(REGIONS)) % len(NOTICE_TYPES)]
        method = METHODS[(i + (i // 7)) % len(METHODS)]
        theme, low, high = PROJECT_THEMES[(i * 5 + i // 11) % len(PROJECT_THEMES)]
        year = 2023 + (i % 4)
        notice_day = start + timedelta(days=(i * 3 + rng.randint(0, 18)) % days_span)
        budget = rng.randint(low // 1000, high // 1000) * 1000
        if notice_type == "采购公告":
            contract = 0
            sign_day = ""
        else:
            discount = rng.uniform(0.86, 0.995)
            contract = int(round(budget * discount / 100.0) * 100)
            sign_day = (notice_day - timedelta(days=rng.randint(0, 18))).isoformat()

        buyer_dept = BUYER_DEPTS[(i + len(theme)) % len(BUYER_DEPTS)]
        stage = ["第一批", "第二批", "第三批", "专项", "补充", "年度"][i % 6]
        project_name = f"{region}{theme}（{year}年{stage}）"
        rows.append(
            {
                "record_id": f"FJ-PUB-{i + 1:04d}",
                "source_kind": "official_public_structured_sample",
                "region": region,
                "notice_type": notice_type,
                "project_no": make_project_no(region_code, method, year, i + 1),
                "project_name": project_name,
                "buyer": f"{region}{buyer_dept}",
                "supplier": "" if notice_type == "采购公告" else supplier_name(i),
                "procurement_method": method,
                "budget_amount": budget,
                "contract_amount": contract,
                "notice_date": notice_day.isoformat(),
                "sign_date": sign_day,
                "source_url": SOURCE_URLS[i % len(SOURCE_URLS)],
                "raw_summary": "福建官方公开数据字段口径扩展样本：按采购公告、结果公告、合同公告的公开字段组织，用于课程原型的批量存证、异常识别和监管闭环实验。",
            }
        )
    return rows[:target_count]


def make_simulation_rows(seeds: pd.DataFrame, official_rows: list[dict[str, object]], target_count: int) -> list[dict[str, object]]:
    existing = seeds[seeds["source_kind"].eq("course_simulation")].copy()
    rows = [row.to_dict() for _, row in existing.iterrows()]
    base_candidates = [row for row in official_rows if row.get("notice_type") != "采购公告"]

    for i in range(max(target_count - len(rows), 0)):
        base = dict(base_candidates[(i * 17) % len(base_candidates)])
        sim_no = len(rows) + 1
        base["record_id"] = f"SIM-{sim_no:03d}"
        base["source_kind"] = "course_simulation"
        base["source_url"] = f"local://course-simulation/sim-{sim_no:03d}"
        pattern = i % 4
        if pattern == 0:
            base["contract_amount"] = int(float(base["budget_amount"]) * 6.5)
            base["raw_summary"] = "课程模拟：合同金额被放大，用于验证金额偏离和篡改校验。"
        elif pattern == 1:
            base["project_name"] = "公共资源交易电子合同平台运维服务重复采购模拟样本"
            base["raw_summary"] = "课程模拟：项目名称高度重复，用于验证文本相似度预警。"
        elif pattern == 2:
            base["supplier"] = "福建省海峡信息科技有限公司"
            base["raw_summary"] = "课程模拟：同一供应商集中出现，用于验证主体集中度指标。"
        else:
            base["sign_date"] = "2023-01-01"
            base["notice_date"] = "2024-08-30"
            base["raw_summary"] = "课程模拟：签订日期与公告日期间隔异常，用于验证时间规则。"
        rows.append(base)
    return rows[:target_count]


def build_dataset(target_total: int, simulation_count: int) -> pd.DataFrame:
    seeds = ensure_seed_file()
    official_count = target_total - simulation_count
    official_rows = make_official_like_rows(seeds, official_count)
    simulation_rows = make_simulation_rows(seeds, official_rows, simulation_count)
    df = pd.DataFrame(official_rows + simulation_rows)
    df = df[
        [
            "record_id",
            "source_kind",
            "region",
            "notice_type",
            "project_no",
            "project_name",
            "buyer",
            "supplier",
            "procurement_method",
            "budget_amount",
            "contract_amount",
            "notice_date",
            "sign_date",
            "source_url",
            "raw_summary",
        ]
    ]
    return df.fillna("")


def main() -> None:
    parser = argparse.ArgumentParser(description="扩充福建公共资源交易/政府采购课程实验样本。")
    parser.add_argument("--target", type=int, default=1260, help="输出总记录数，建议 1000-3000。")
    parser.add_argument("--simulations", type=int, default=30, help="课程模拟风险样本数量。")
    args = parser.parse_args()
    if args.target < 500:
        raise ValueError("样本总量不应低于 500。")
    if args.simulations >= args.target:
        raise ValueError("模拟样本数量必须小于总样本数。")

    df = build_dataset(args.target, args.simulations)
    df.to_csv(SAMPLE_PATH, index=False, encoding="utf-8-sig")
    official_count = int(df["source_kind"].astype(str).str.startswith("official").sum())
    print(f"已生成 {len(df)} 条样本：官方公开字段样本 {official_count} 条，课程模拟风险样本 {args.simulations} 条。")
    print(SAMPLE_PATH)


if __name__ == "__main__":
    main()

from __future__ import annotations

import re
import sys
from pathlib import Path
from typing import Dict

import pandas as pd
import requests
from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parents[1]


SOURCE_URLS = [
    "https://zfcg.czt.fujian.gov.cn/",
    "https://ggzyfw.fujian.gov.cn/",
]


def normalize_text(html: str) -> str:
    """把网页 HTML 转成较干净的纯文本，便于后续正则抽取字段。"""
    soup = BeautifulSoup(html, "html.parser")
    for tag in soup(["script", "style"]):
        tag.extract()
    return re.sub(r"\s+", " ", soup.get_text(" ", strip=True))


def pick(pattern: str, text: str) -> str:
    match = re.search(pattern, text)
    return match.group(1).strip() if match else ""


def parse_notice_text(text: str, url: str) -> Dict[str, str]:
    """针对政府采购公告常见字段做保守解析，解析不到就留空。"""
    return {
        "source_url": url,
        "project_no": pick(r"项目编号[:：]\s*([A-Za-z0-9\[\]\-]+)", text),
        "project_name": pick(r"项目名称[:：]\s*([^ ]{4,80})", text),
        "buyer": pick(r"(?:采购人|甲方)[:：]\s*([^ ]{2,60})", text),
        "supplier": pick(r"(?:供应商|乙方|中标供应商)[:：]\s*([^ ]{2,80})", text),
        "procurement_method": pick(r"采购方式[:：]\s*([^ ]{2,20})", text),
        "contract_amount": pick(r"(?:合同金额|中标金额|成交金额)[:：]\s*([0-9,.]+)", text),
    }


def fetch_and_parse(url: str) -> Dict[str, str]:
    """下载并解析单个公开页面；遇到验证码或动态页面时会返回较少字段。"""
    response = requests.get(url, timeout=15, headers={"User-Agent": "Mozilla/5.0"})
    response.raise_for_status()
    text = normalize_text(response.text)
    return parse_notice_text(text, url)


def main() -> None:
    if len(sys.argv) <= 1:
        print("用法：python scripts\\scrape_fujian_pages.py <公告详情页URL1> <公告详情页URL2>")
        print("提示：福建政府采购列表页可能存在验证码，建议传入公开详情页 URL。")
        return

    rows = [fetch_and_parse(url) for url in sys.argv[1:]]
    out = ROOT / "outputs" / "scraped_pages.csv"
    out.parent.mkdir(exist_ok=True)
    pd.DataFrame(rows).to_csv(out, index=False, encoding="utf-8-sig")
    print(f"解析完成：{out}")


if __name__ == "__main__":
    main()


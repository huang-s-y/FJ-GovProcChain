// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @title RecordRegistry
/// @notice 面向公共资源交易数据的轻量级哈希存证与风险状态流转合约
contract RecordRegistry {
    enum RiskStatus {
        Registered,
        Warned,
        Reviewing,
        Closed
    }

    struct Record {
        string recordId;
        string recordType;
        bytes32 dataHash;
        string sourceUri;
        address uploader;
        uint256 createdAt;
        uint256 version;
        RiskStatus status;
        uint256 riskScore;
        string riskReason;
        string conclusion;
        bool exists;
    }

    struct TraceEvent {
        RiskStatus fromStatus;
        RiskStatus toStatus;
        address operator;
        string comment;
        uint256 timestamp;
    }

    mapping(string => Record) private records;
    mapping(string => TraceEvent[]) private traces;
    string[] private recordIds;

    event RecordRegistered(string indexed recordId, bytes32 dataHash, address indexed uploader);
    event RecordUpdated(string indexed recordId, bytes32 oldHash, bytes32 newHash, string reason);
    event RecordVerified(string indexed recordId, bool passed);
    event RiskMarked(string indexed recordId, uint256 riskScore, string riskReason);
    event ReviewStarted(string indexed recordId, address indexed operator);
    event RiskClosed(string indexed recordId, string conclusion);

    /// 中文注释：登记一条采购/合同记录的哈希摘要，链上只存哈希和元数据，不存公告全文。
    function registerRecord(
        string calldata recordId,
        string calldata recordType,
        bytes32 dataHash,
        string calldata sourceUri
    ) external {
        require(!records[recordId].exists, "record already exists");
        records[recordId] = Record({
            recordId: recordId,
            recordType: recordType,
            dataHash: dataHash,
            sourceUri: sourceUri,
            uploader: msg.sender,
            createdAt: block.timestamp,
            version: 1,
            status: RiskStatus.Registered,
            riskScore: 0,
            riskReason: "",
            conclusion: "",
            exists: true
        });
        recordIds.push(recordId);
        _appendTrace(recordId, RiskStatus.Registered, RiskStatus.Registered, "数据哈希登记");
        emit RecordRegistered(recordId, dataHash, msg.sender);
    }

    /// 中文注释：当链下数据发生合规更正时，写入新哈希并保留版本变更原因。
    function updateRecord(
        string calldata recordId,
        bytes32 newHash,
        string calldata reason
    ) external {
        require(records[recordId].exists, "record not found");
        bytes32 oldHash = records[recordId].dataHash;
        records[recordId].dataHash = newHash;
        records[recordId].version += 1;
        _appendTrace(recordId, records[recordId].status, records[recordId].status, reason);
        emit RecordUpdated(recordId, oldHash, newHash, reason);
    }

    /// 中文注释：重新传入链下计算出的哈希，与链上哈希比较，判断数据是否被篡改。
    function verifyRecord(string calldata recordId, bytes32 candidateHash) external returns (bool) {
        require(records[recordId].exists, "record not found");
        bool passed = records[recordId].dataHash == candidateHash;
        emit RecordVerified(recordId, passed);
        return passed;
    }

    /// 中文注释：异常识别模型发现风险后，把风险分数和原因写入链上状态。
    function markRisk(
        string calldata recordId,
        uint256 riskScore,
        string calldata riskReason
    ) external {
        _markRisk(recordId, riskScore, riskReason);
    }

    /// 中文注释：保留完整方案中的 flagRisk 命名，便于论文与代码对应。
    function flagRisk(
        string calldata recordId,
        string calldata riskType,
        uint256 riskScore
    ) external {
        _markRisk(recordId, riskScore, riskType);
    }

    function _markRisk(
        string calldata recordId,
        uint256 riskScore,
        string calldata riskReason
    ) internal {
        require(records[recordId].exists, "record not found");
        require(riskScore <= 100, "risk score must be 0-100");
        Record storage item = records[recordId];
        RiskStatus oldStatus = item.status;
        item.status = RiskStatus.Warned;
        item.riskScore = riskScore;
        item.riskReason = riskReason;
        _appendTrace(recordId, oldStatus, RiskStatus.Warned, riskReason);
        emit RiskMarked(recordId, riskScore, riskReason);
    }

    /// 中文注释：监管人员开始核查后，将状态从“已预警”推进到“核查中”。
    function startReview(string calldata recordId) external {
        require(records[recordId].exists, "record not found");
        require(records[recordId].status == RiskStatus.Warned, "status must be warned");
        RiskStatus oldStatus = records[recordId].status;
        records[recordId].status = RiskStatus.Reviewing;
        _appendTrace(recordId, oldStatus, RiskStatus.Reviewing, "监管人员开始核查");
        emit ReviewStarted(recordId, msg.sender);
    }

    /// 中文注释：核查结束后写入处理结论，形成完整可追溯闭环。
    function closeRisk(string calldata recordId, string calldata conclusion) external {
        require(records[recordId].exists, "record not found");
        require(records[recordId].status == RiskStatus.Reviewing, "status must be reviewing");
        RiskStatus oldStatus = records[recordId].status;
        records[recordId].status = RiskStatus.Closed;
        records[recordId].conclusion = conclusion;
        _appendTrace(recordId, oldStatus, RiskStatus.Closed, conclusion);
        emit RiskClosed(recordId, conclusion);
    }

    /// 中文注释：通用核查接口，对应完整方案中的 reviewRisk(recordId, status, comment)。
    function reviewRisk(
        string calldata recordId,
        RiskStatus targetStatus,
        string calldata comment
    ) external {
        require(records[recordId].exists, "record not found");
        if (targetStatus == RiskStatus.Reviewing) {
            require(records[recordId].status == RiskStatus.Warned, "status must be warned");
            RiskStatus oldStatus = records[recordId].status;
            records[recordId].status = RiskStatus.Reviewing;
            _appendTrace(recordId, oldStatus, RiskStatus.Reviewing, comment);
            emit ReviewStarted(recordId, msg.sender);
        } else if (targetStatus == RiskStatus.Closed) {
            require(records[recordId].status == RiskStatus.Reviewing, "status must be reviewing");
            RiskStatus oldStatus = records[recordId].status;
            records[recordId].status = RiskStatus.Closed;
            records[recordId].conclusion = comment;
            _appendTrace(recordId, oldStatus, RiskStatus.Closed, comment);
            emit RiskClosed(recordId, comment);
        } else {
            revert("unsupported target status");
        }
    }

    function getRecord(string calldata recordId) external view returns (Record memory) {
        require(records[recordId].exists, "record not found");
        return records[recordId];
    }

    function getRecordCount() external view returns (uint256) {
        return recordIds.length;
    }

    /// 中文注释：查询某条记录从登记、更新、预警到核查关闭的全过程轨迹。
    function getRecordTrace(string calldata recordId) external view returns (TraceEvent[] memory) {
        require(records[recordId].exists, "record not found");
        return traces[recordId];
    }

    function _appendTrace(
        string calldata recordId,
        RiskStatus fromStatus,
        RiskStatus toStatus,
        string memory comment
    ) internal {
        traces[recordId].push(
            TraceEvent({
                fromStatus: fromStatus,
                toStatus: toStatus,
                operator: msg.sender,
                comment: comment,
                timestamp: block.timestamp
            })
        );
    }
}

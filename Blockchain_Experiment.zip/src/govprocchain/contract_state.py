from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from typing import Dict, List


REGISTERED = "已登记"
WARNED = "已预警"
REVIEWING = "核查中"
CLOSED = "已关闭"


@dataclass
class StatusEvent:
    record_id: str
    from_status: str
    to_status: str
    operator: str
    reason: str
    timestamp: str


class RiskStatusBook:
    """模拟智能合约中的风险状态机。

    这里保留状态流转事件，是为了让异常识别结果进入“可追溯监管流程”，
    而不是只停留在一个离线模型分数。
    """

    def __init__(self) -> None:
        self.status: Dict[str, str] = {}
        self.events: List[StatusEvent] = []

    def register(self, record_id: str, operator: str = "data_admin") -> None:
        self._transition(record_id, "", REGISTERED, operator, "数据哈希登记")

    def mark_warned(self, record_id: str, reason: str, operator: str = "risk_model") -> None:
        self._transition(record_id, self.status.get(record_id, REGISTERED), WARNED, operator, reason)

    def update_record(self, record_id: str, reason: str, operator: str = "data_admin") -> None:
        """模拟合约 updateRecord：记录数据版本变更原因，但不改变监管状态。"""
        current = self.status.get(record_id, REGISTERED)
        self._transition(record_id, current, current, operator, f"数据版本更新：{reason}")

    def start_review(self, record_id: str, operator: str = "regulator") -> None:
        self._transition(record_id, self.status.get(record_id, WARNED), REVIEWING, operator, "监管人员开始核查")

    def close(self, record_id: str, conclusion: str, operator: str = "regulator") -> None:
        self._transition(record_id, self.status.get(record_id, REVIEWING), CLOSED, operator, conclusion)

    def _transition(
        self,
        record_id: str,
        from_status: str,
        to_status: str,
        operator: str,
        reason: str,
    ) -> None:
        self.status[record_id] = to_status
        self.events.append(
            StatusEvent(
                record_id=record_id,
                from_status=from_status,
                to_status=to_status,
                operator=operator,
                reason=reason,
                timestamp=datetime.now(timezone.utc).isoformat(),
            )
        )

    def event_dicts(self) -> List[Dict[str, str]]:
        return [asdict(event) for event in self.events]

    def get_record_trace(self, record_id: str) -> List[Dict[str, str]]:
        """查询单条记录从登记到关闭的完整轨迹。"""
        return [asdict(event) for event in self.events if event.record_id == record_id]

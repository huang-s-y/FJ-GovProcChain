from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from typing import Dict, List

from .hash_utils import sha256_digest


@dataclass
class Block:
    index: int
    timestamp: str
    record_id: str
    data_hash: str
    previous_hash: str
    block_hash: str


class MockEvidenceChain:
    """用于课程基础版的轻量级模拟链。

    真实区块链会由共识网络维护区块，本类只模拟“前一区块哈希 + 当前数据哈希”
    的链式结构，便于在没有 Solidity 环境时完成存证和追溯实验。
    """

    def __init__(self) -> None:
        self.blocks: List[Block] = []
        self.append_record("GENESIS", "0" * 64)

    def append_record(self, record_id: str, data_hash: str) -> Block:
        """追加一条存证记录，并把前一区块哈希写入当前区块。"""
        previous_hash = self.blocks[-1].block_hash if self.blocks else "0" * 64
        timestamp = datetime.now(timezone.utc).isoformat()
        index = len(self.blocks)
        payload = f"{index}|{timestamp}|{record_id}|{data_hash}|{previous_hash}"
        block = Block(
            index=index,
            timestamp=timestamp,
            record_id=record_id,
            data_hash=data_hash,
            previous_hash=previous_hash,
            block_hash=sha256_digest(payload),
        )
        self.blocks.append(block)
        return block

    def verify_chain(self) -> bool:
        """校验每个区块是否正确指向前一区块，发现断链即返回 False。"""
        for current, previous in zip(self.blocks[1:], self.blocks[:-1]):
            if current.previous_hash != previous.block_hash:
                return False
        return True

    def to_dicts(self) -> List[Dict[str, str]]:
        return [asdict(block) for block in self.blocks]


from __future__ import annotations

import re
from difflib import SequenceMatcher
from typing import Dict, List

import numpy as np
import pandas as pd

DEFAULT_WEIGHTS: Dict[str, float] = {
    "amount_score": 0.30,
    "text_score": 0.25,
    "subject_score": 0.20,
    "time_score": 0.15,
    "completeness_score": 0.10,
}

RISK_BINS = [-np.inf, 10, 30, 60, np.inf]
RISK_LABELS = ["正常", "低风险", "中风险", "高风险"]


def _safe_amount(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series, errors="coerce").fillna(0.0)


def _max_title_similarity(title: str, others: List[str]) -> float:
    """计算当前项目名称与其他项目名称的最高相似度。"""
    if not title:
        return 0.0
    scores = [
        SequenceMatcher(None, str(title), str(other)).ratio()
        for other in others
        if str(other) and str(other) != str(title)
    ]
    return max(scores, default=0.0)


def _title_similarity_scores(titles: List[str]) -> List[float]:
    """优先使用 TF-IDF + 余弦相似度；未安装 sklearn 时退化为字符相似度。"""
    try:
        from sklearn.feature_extraction.text import TfidfVectorizer
        from sklearn.metrics.pairwise import cosine_similarity

        vectorizer = TfidfVectorizer(analyzer="char", ngram_range=(2, 4))
        matrix = vectorizer.fit_transform(titles)
        sim = cosine_similarity(matrix)
        np.fill_diagonal(sim, 0.0)
        return sim.max(axis=1).tolist()
    except Exception:
        if len(titles) <= 300:
            return [_max_title_similarity(title, titles) for title in titles]

        buckets: dict[str, list[tuple[int, str]]] = {}
        normalized = [
            re.sub(r"[（(].*?[）)]", "", str(title)).replace("福建省省级", "").strip()
            for title in titles
        ]
        for idx, title in enumerate(normalized):
            key = title[:14] if len(title) >= 14 else title
            buckets.setdefault(key, []).append((idx, title))

        scores = [0.0] * len(titles)
        for items in buckets.values():
            if len(items) <= 1:
                continue
            for pos, (idx, title) in enumerate(items):
                candidates = [other for j, other in items[max(0, pos - 30) : pos + 31] if j != idx]
                scores[idx] = _max_title_similarity(title, candidates)
        return scores


def _c_factor(size: int) -> float:
    """Isolation Forest 的平均路径长度校正项 c(n)。"""
    if size <= 1:
        return 0.0
    if size == 2:
        return 1.0
    return 2.0 * (np.log(size - 1) + 0.5772156649) - (2.0 * (size - 1) / size)


def _build_isolation_tree(x: np.ndarray, depth: int, max_depth: int, rng: np.random.Generator) -> dict:
    if depth >= max_depth or len(x) <= 1:
        return {"size": len(x)}

    ranges = np.ptp(x, axis=0)
    candidates = np.flatnonzero(ranges > 1e-12)
    if len(candidates) == 0:
        return {"size": len(x)}

    feature = int(rng.choice(candidates))
    min_value = float(np.min(x[:, feature]))
    max_value = float(np.max(x[:, feature]))
    split = float(rng.uniform(min_value, max_value))
    left_mask = x[:, feature] < split
    if left_mask.all() or (~left_mask).all():
        return {"size": len(x)}

    return {
        "feature": feature,
        "split": split,
        "left": _build_isolation_tree(x[left_mask], depth + 1, max_depth, rng),
        "right": _build_isolation_tree(x[~left_mask], depth + 1, max_depth, rng),
    }


def _path_length(row: np.ndarray, node: dict, depth: int = 0) -> float:
    if "feature" not in node:
        return depth + _c_factor(int(node.get("size", 1)))
    branch = "left" if row[int(node["feature"])] < float(node["split"]) else "right"
    return _path_length(row, node[branch], depth + 1)


def _robust_scale(frame: pd.DataFrame) -> np.ndarray:
    values = frame.replace([np.inf, -np.inf], 0).fillna(0).astype(float).to_numpy()
    med = np.median(values, axis=0)
    q1 = np.percentile(values, 25, axis=0)
    q3 = np.percentile(values, 75, axis=0)
    iqr = np.where((q3 - q1) > 1e-9, q3 - q1, 1.0)
    return (values - med) / iqr


def _lightweight_isolation_forest(
    frame: pd.DataFrame,
    contamination: float = 0.04,
    n_estimators: int = 100,
    max_samples: int = 256,
    random_state: int = 42,
) -> tuple[np.ndarray, np.ndarray, str]:
    """无外部依赖的 Isolation Forest 实现，保证课程环境中算法真实参与评分。"""
    x = _robust_scale(frame)
    n_rows = len(x)
    if n_rows == 0:
        return np.array([]), np.array([]), "empty"

    sample_size = min(max_samples, n_rows)
    max_depth = int(np.ceil(np.log2(max(sample_size, 2))))
    rng = np.random.default_rng(random_state)
    trees = []
    for _ in range(n_estimators):
        sample_idx = rng.choice(n_rows, size=sample_size, replace=False)
        trees.append(_build_isolation_tree(x[sample_idx], 0, max_depth, rng))

    avg_path = np.array(
        [np.mean([_path_length(row, tree) for tree in trees]) for row in x],
        dtype=float,
    )
    raw_score = np.power(2.0, -avg_path / max(_c_factor(sample_size), 1e-9))
    percentile_score = pd.Series(raw_score).rank(pct=True, method="average").to_numpy() * 100
    if np.ptp(raw_score) <= 1e-12:
        return percentile_score, np.ones(n_rows, dtype=int), "lightweight"
    cutoff = np.percentile(raw_score, 100 * (1 - contamination))
    labels = np.where(raw_score >= cutoff, -1, 1)
    return percentile_score, labels, "lightweight"


def _isolation_forest_scores(frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray, str]:
    try:
        from sklearn.ensemble import IsolationForest

        model_features = frame.replace([np.inf, -np.inf], 0).fillna(0)
        model = IsolationForest(n_estimators=120, contamination=0.04, random_state=42)
        labels = model.fit_predict(model_features)
        raw = -model.decision_function(model_features)
        scores = pd.Series(raw).rank(pct=True, method="average").to_numpy() * 100
        return scores, labels, "sklearn"
    except Exception:
        return _lightweight_isolation_forest(frame)


def _assign_risk_level(score: pd.Series) -> pd.Series:
    return pd.cut(score, bins=RISK_BINS, labels=RISK_LABELS, right=False).astype(str)


def _red_flag_score(result: pd.DataFrame, weights: dict[str, float]) -> pd.Series:
    score = pd.Series(0.0, index=result.index)
    for name, weight in weights.items():
        score += result[name].astype(float) * weight
    return score.clip(0, 100).round(2)


def build_features(df: pd.DataFrame) -> pd.DataFrame:
    """构造异常识别特征，覆盖金额、主体、文本、时间和字段完整性。"""
    features = df.copy()
    amount = _safe_amount(features["contract_amount"]).where(
        _safe_amount(features["contract_amount"]) > 0,
        _safe_amount(features["budget_amount"]),
    )
    features["amount_for_model"] = amount
    median = float(np.median(amount[amount > 0])) if (amount > 0).any() else 0.0
    mad = float(np.median(np.abs(amount[amount > 0] - median))) if (amount > 0).any() else 1.0
    mad = mad if mad > 0 else 1.0

    # 金额偏离使用稳健 MAD 指标，避免少量极端值把均值和标准差拉偏。
    features["amount_mad_z"] = np.abs(amount - median) / mad

    # 同一供应商出现比例越高，越值得监管人员关注，但不直接等同违规。
    supplier_counts = features["supplier"].replace("", np.nan).value_counts(dropna=True)
    total_with_supplier = max(int(features["supplier"].replace("", np.nan).notna().sum()), 1)
    features["supplier_count"] = features["supplier"].map(supplier_counts).fillna(0).astype(int)
    features["supplier_share"] = features["supplier_count"] / total_with_supplier
    pair_counts = (
        features["buyer"].fillna("").astype(str)
        + "||"
        + features["supplier"].fillna("").astype(str)
    ).replace(r"^\|\|$", np.nan, regex=True).value_counts(dropna=True)
    pair_key = features["buyer"].fillna("").astype(str) + "||" + features["supplier"].fillna("").astype(str)
    features["buyer_supplier_pair_count"] = pair_key.map(pair_counts).fillna(0).astype(int)
    supplier_degree = features.groupby("supplier")["buyer"].transform(lambda col: col.replace("", np.nan).nunique())
    buyer_degree = features.groupby("buyer")["supplier"].transform(lambda col: col.replace("", np.nan).nunique())
    features["supplier_buyer_degree"] = supplier_degree.fillna(0).astype(int)
    features["buyer_supplier_degree"] = buyer_degree.fillna(0).astype(int)

    titles = features["project_name"].fillna("").astype(str).tolist()
    features["title_similarity"] = _title_similarity_scores(titles)

    notice_date = pd.to_datetime(features["notice_date"], errors="coerce")
    sign_date = pd.to_datetime(features["sign_date"], errors="coerce")
    features["sign_notice_gap_days"] = (notice_date - sign_date).dt.days.fillna(0)

    required = ["project_no", "project_name", "buyer", "procurement_method", "notice_date"]
    features["missing_required_fields"] = features[required].isna().sum(axis=1) + (
        features[required].astype(str).apply(lambda col: col.str.strip().eq("")).sum(axis=1)
    )

    # 完整方案中的五类风险分：金额、文本、主体、时间、字段完整性。
    features["amount_score"] = np.clip(features["amount_mad_z"] * 18, 0, 100)
    features["text_score"] = np.where(
        features["title_similarity"] >= 0.88,
        np.clip(features["title_similarity"] * 100, 0, 100),
        np.where(features["title_similarity"] >= 0.75, 55, 0),
    )
    features["subject_score"] = np.where(
        (features["supplier_count"] >= 3) & (features["supplier_share"] >= 0.20),
        np.clip(features["supplier_share"] * 180, 50, 100),
        np.where(features["supplier_count"] >= 2, 35, 0),
    )
    gap_abs = features["sign_notice_gap_days"].abs()
    features["time_score"] = np.where(
        (features["sign_notice_gap_days"] > 30) | (features["sign_notice_gap_days"] < -1),
        np.clip(gap_abs * 3, 45, 100),
        0,
    )
    features["completeness_score"] = np.clip(
        features["missing_required_fields"] / max(len(required), 1) * 100,
        0,
        100,
    )
    features["graph_score"] = np.clip(
        features["supplier_share"] * 140
        + np.where(features["buyer_supplier_pair_count"] >= 2, 20, 0)
        + np.where(features["supplier_buyer_degree"] >= 5, 15, 0)
        + np.where(features["buyer_supplier_degree"] >= 6, 10, 0),
        0,
        100,
    )
    features.loc[features["supplier"].fillna("").astype(str).str.strip().eq(""), "graph_score"] = 0
    max_pair_count = max(int(features["buyer_supplier_pair_count"].max()), 1)
    max_supplier_degree = max(int(features["supplier_buyer_degree"].max()), 1)
    supplier_amount_pressure = features.groupby("supplier")["amount_mad_z"].transform("mean").fillna(0)
    buyer_amount_pressure = features.groupby("buyer")["amount_mad_z"].transform("mean").fillna(0)
    edge_repeat_component = (
        np.log1p(features["buyer_supplier_pair_count"]) / np.log1p(max_pair_count) * 100
        if max_pair_count > 1
        else 0
    )
    supplier_degree_component = features["supplier_buyer_degree"] / max_supplier_degree * 100
    neighborhood_amount_component = np.clip((0.65 * supplier_amount_pressure + 0.35 * buyer_amount_pressure) * 12, 0, 100)
    features["graph_propagation_score"] = np.clip(
        0.35 * features["graph_score"].astype(float)
        + 0.25 * edge_repeat_component
        + 0.20 * supplier_degree_component
        + 0.20 * neighborhood_amount_component,
        0,
        100,
    ).round(2)
    features.loc[features["supplier"].fillna("").astype(str).str.strip().eq(""), "graph_propagation_score"] = 0
    return features


def detect_anomalies(
    df: pd.DataFrame,
    weights: dict[str, float] | None = None,
    threshold: float = 30.0,
) -> pd.DataFrame:
    """输出红旗指标增强 Isolation Forest 的异常识别结果。"""
    result = build_features(df)
    weights = weights or DEFAULT_WEIGHTS
    result["red_flag_score"] = _red_flag_score(result, weights)
    result["graph_enhanced_score"] = (
        0.80 * result["red_flag_score"].astype(float)
        + 0.20 * result["graph_score"].astype(float)
    ).clip(0, 100).round(2)

    iforest_features = result[
        [
            "amount_for_model",
            "amount_mad_z",
            "supplier_share",
            "title_similarity",
            "sign_notice_gap_days",
            "missing_required_fields",
            "amount_score",
            "text_score",
            "subject_score",
            "time_score",
            "completeness_score",
            "graph_score",
        ]
    ]
    iforest_score, iforest_label, backend = _isolation_forest_scores(iforest_features)
    result["iforest_score"] = np.round(iforest_score, 2)
    result["iforest_label"] = iforest_label
    result["iforest_backend"] = backend
    iforest_component = np.where(
        result["iforest_label"].eq(-1),
        np.clip(30 + (result["iforest_score"] - 96) * 7, 30, 58),
        np.clip((result["iforest_score"] - 50) * 0.2, 0, 9.9),
    )
    result["iforest_calibrated_score"] = np.round(iforest_component, 2)
    result["iforest_boost"] = np.round(np.maximum(iforest_component - result["red_flag_score"].astype(float), 0), 2)
    result["hybrid_risk_score"] = np.maximum(
        result["red_flag_score"].astype(float),
        iforest_component,
    ).clip(0, 100).round(2)
    result["rule_risk_score"] = result["hybrid_risk_score"]

    reasons: List[str] = []

    for _, row in result.iterrows():
        row_reasons: List[str] = []

        if row["amount_score"] >= 60:
            row_reasons.append("合同/预算金额相对样本中位数偏离较大")
        if row["subject_score"] >= 50:
            row_reasons.append("同一供应商在样本中出现频次较高")
        if row["text_score"] >= 60:
            row_reasons.append("项目名称与其他记录高度相似")
        if row["time_score"] >= 45:
            row_reasons.append("签订日期与公告日期间隔异常")
        if row["completeness_score"] > 0:
            row_reasons.append("必要字段存在缺失")
        if row["iforest_label"] == -1:
            row_reasons.append("孤立森林判定为多特征离群点")

        reasons.append("；".join(row_reasons) if row_reasons else "未触发规则风险")

    result["risk_reason"] = reasons
    result["risk_level"] = _assign_risk_level(result["rule_risk_score"])
    result["is_review_candidate"] = result["rule_risk_score"] >= threshold
    return result

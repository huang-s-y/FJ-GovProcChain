from __future__ import annotations

from pathlib import Path

import pandas as pd


def load_procurement_csv(path: str | Path) -> pd.DataFrame:
    """读取政府采购样本，并统一金额字段类型。

    该模块对应完整方案中的 src/data_loader.py，用于把官方公开页面整理后的
    CSV 样本转成后续哈希存证和异常识别模块可以直接使用的数据表。
    """
    df = pd.read_csv(path, dtype=str).fillna("")
    for column in ["budget_amount", "contract_amount"]:
        if column in df.columns:
            df[column] = pd.to_numeric(df[column], errors="coerce").fillna(0)
    return df


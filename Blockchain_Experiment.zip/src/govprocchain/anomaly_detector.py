"""完整方案中 anomaly_detector.py 的兼容入口。"""

from .anomaly import build_features, detect_anomalies

__all__ = ["build_features", "detect_anomalies"]


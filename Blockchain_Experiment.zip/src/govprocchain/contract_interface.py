"""基础版模拟合约接口；增强版可替换为 web3.py 调用 Solidity 合约。"""

from .contract_state import CLOSED, REGISTERED, REVIEWING, WARNED, RiskStatusBook

__all__ = ["RiskStatusBook", "REGISTERED", "WARNED", "REVIEWING", "CLOSED"]


import hashlib
import json
from datetime import datetime
from typing import Any, Dict, Iterable


HASH_FIELDS: Iterable[str] = (
    "record_id",
    "region",
    "notice_type",
    "project_no",
    "project_name",
    "buyer",
    "supplier",
    "procurement_method",
    "budget_amount",
    "contract_amount",
    "notice_date",
    "sign_date",
    "source_url",
    "raw_summary",
)


def _is_empty(value: Any) -> bool:
    return value is None or str(value).strip() == "" or str(value).strip().lower() == "nan"


def _normalize_amount(value: Any) -> str | None:
    """金额统一保留两位小数，避免 100、100.0、100.00 产生不同哈希。"""
    if _is_empty(value):
        return None
    cleaned = str(value).replace(",", "").replace("元", "").strip()
    try:
        return f"{float(cleaned):.2f}"
    except ValueError:
        return str(value).strip()


def _normalize_date(value: Any) -> str | None:
    """日期统一为 YYYY-MM-DD；解析失败时保留清洗后的原值。"""
    if _is_empty(value):
        return None
    text = str(value).strip().replace("年", "-").replace("月", "-").replace("日", "")
    for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%Y.%m.%d"):
        try:
            return datetime.strptime(text[:10], fmt).date().isoformat()
        except ValueError:
            continue
    return text


def _normalize_text(value: Any) -> str | None:
    if _is_empty(value):
        return None
    return " ".join(str(value).strip().split())


def normalize_field(field: str, value: Any) -> str | None:
    """按照完整方案的规范化规则处理字段：空值 null、日期 ISO、金额两位小数、文本去空白。"""
    if field in {"budget_amount", "contract_amount"}:
        return _normalize_amount(value)
    if field in {"notice_date", "sign_date"}:
        return _normalize_date(value)
    return _normalize_text(value)


def canonical_record(record: Dict[str, Any]) -> Dict[str, str | None]:
    """提取参与存证的核心字段，并转换成稳定的字符串形式。"""
    canonical: Dict[str, str | None] = {}
    for field in HASH_FIELDS:
        canonical[field] = normalize_field(field, record.get(field, None))
    return canonical


def canonical_json(record: Dict[str, Any]) -> str:
    """生成字段顺序稳定的 JSON，避免同一记录因列顺序不同导致哈希变化。"""
    return json.dumps(
        canonical_record(record),
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )


def sha256_digest(text: str) -> str:
    """计算 SHA-256 摘要，作为链上存证的数据指纹。"""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def hash_record(record: Dict[str, Any]) -> str:
    """对采购记录生成哈希值。"""
    return sha256_digest(canonical_json(record))


def verify_record(record: Dict[str, Any], expected_hash: str) -> bool:
    """重新计算记录哈希，并与登记哈希比较，用于篡改校验。"""
    return hash_record(record) == expected_hash

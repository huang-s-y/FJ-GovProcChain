"""完整方案中 blockchain_sim.py 的兼容入口。"""

from .mock_chain import Block, MockEvidenceChain

__all__ = ["Block", "MockEvidenceChain"]


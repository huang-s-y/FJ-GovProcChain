from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pandas as pd
import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
OUTPUT_DIR = ROOT / "outputs"


def ensure_outputs() -> None:
    """首次打开看板时自动运行实验脚本，避免用户看到空页面。"""
    if not (OUTPUT_DIR / "summary.json").exists():
        subprocess.run([sys.executable, str(ROOT / "scripts" / "run_pipeline.py")], check=True)


def load_csv(name: str) -> pd.DataFrame:
    return pd.read_csv(OUTPUT_DIR / name)


st.set_page_config(page_title="FJ-GovProcChain 监管看板", layout="wide")
ensure_outputs()

summary = json.loads((OUTPUT_DIR / "summary.json").read_text(encoding="utf-8"))
registry = load_csv("registry.csv")
anomaly = load_csv("anomaly_results.csv")
events = load_csv("status_events.csv")
storage = load_csv("storage_efficiency.csv")
sensitivity = load_csv("sensitivity_results.csv")
model_comparison = load_csv("model_comparison.csv")
contract_log = load_csv("solidity_call_log.csv")
regulatory_recall = load_csv("regulatory_model_recall.csv")
regulatory_validation = load_csv("regulatory_positive_validation.csv")

st.title("FJ-GovProcChain 公共资源交易数据可信治理原型")

cols = st.columns(6)
cols[0].metric("样本总数", summary["total_records"])
cols[1].metric("官方公开字段样本", summary["official_excerpt_records"])
cols[2].metric("模拟风险样本", summary["simulation_records"])
cols[3].metric("风险记录", summary["risk_records"])
cols[4].metric("状态事件", summary["status_events"])
cols[5].metric("存储节省", f"{summary['storage_saving_ratio_at_sample']:.2%}")

tab_overview, tab_model, tab_contract, tab_trace = st.tabs(["总览", "异常识别", "合约调用", "监管追溯"])

with tab_overview:
    left, right = st.columns([1, 1])
    risk_order = ["正常", "低风险", "中风险", "高风险"]
    risk_counts = anomaly["risk_level"].value_counts().reindex(risk_order).fillna(0).astype(int)
    left.subheader("异常识别结果分布")
    left.bar_chart(risk_counts)
    right.subheader("链上链下存储效率")
    right.dataframe(storage, use_container_width=True)
    st.subheader("哈希存证登记表")
    st.dataframe(registry.head(200), use_container_width=True)

with tab_model:
    st.subheader("模型对比")
    st.dataframe(model_comparison, use_container_width=True)
    st.subheader("公开监管正例外部验证")
    st.caption("公开处罚案例只提供正例标签，因此这里展示正例召回和复核命中，不展示真实场景准确率。")
    st.dataframe(regulatory_recall, use_container_width=True)
    st.dataframe(
        regulatory_validation[
            [
                "record_id",
                "project_name",
                "supplier",
                "violation_type",
                "rule_risk_score",
                "risk_level",
                "review_hit",
            ]
        ],
        use_container_width=True,
    )
    st.subheader("异常识别结果")
    show_cols = [
        "record_id",
        "source_kind",
        "project_name",
        "supplier",
        "contract_amount",
        "red_flag_score",
        "iforest_score",
        "iforest_calibrated_score",
        "rule_risk_score",
        "risk_level",
        "risk_reason",
    ]
    st.dataframe(anomaly[show_cols].sort_values("rule_risk_score", ascending=False), use_container_width=True)

with tab_contract:
    st.subheader("Solidity 合约部署与调用日志")
    st.dataframe(contract_log, use_container_width=True)
    st.subheader("参数敏感性")
    st.dataframe(sensitivity, use_container_width=True)

with tab_trace:
    st.subheader("监管状态流转事件")
    st.dataframe(events, use_container_width=True)
